"""
Brixometer Lot Registry — FastAPI service.

Scope, deliberately narrow: this service issues lot QR codes at the field edge,
records chain of custody, and stores device-signed grade records so a farmer or
an auditor can later verify a payment. It does **not** compute grades. Grading
happens on the device, where the signature is generated; a server that could
recompute a grade could also quietly change one.

    uvicorn backend.app:app --reload   ->  http://127.0.0.1:8000/docs
"""

from __future__ import annotations

import io
import json
from datetime import datetime, timezone
from typing import Optional

import qrcode
from fastapi import Depends, FastAPI, HTTPException
from fastapi.responses import StreamingResponse
from pydantic import BaseModel, Field
from sqlmodel import Field as SQLField, Session, SQLModel, create_engine, select

import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "ml"))
from arrhenius_tti import BackcastStatus, gated_backcast_from_tti  # noqa: E402

DB_URL = "sqlite:///brixometer.db"
engine = create_engine(DB_URL, echo=False)

app = FastAPI(
    title="Brixometer Lot Registry",
    version="0.4.0",
    description="Chain-of-custody and signed grade records for sugarcane lots.",
)


# --------------------------------------------------------------- models ----
class Lot(SQLModel, table=True):
    lot_id: str = SQLField(primary_key=True)
    farmer_id: str
    fpo_id: str
    variety_hint: str = ""
    harvest_epoch: int
    field_brix: Optional[float] = None
    field_badge: Optional[str] = None
    created_at: str = SQLField(default_factory=lambda: datetime.now(timezone.utc).isoformat())


class Grade(SQLModel, table=True):
    id: Optional[int] = SQLField(default=None, primary_key=True)
    lot_id: str = SQLField(index=True, foreign_key="lot.lot_id")
    arrival_brix: float
    harvest_brix: Optional[float] = None   # None when status != "ok"
    dose: Optional[float] = None
    transit_hours: float
    status: str = BackcastStatus.OK        # ok | integrity_mismatch | exposure_exceeded | tti_unreadable
    device_id: str
    signature: str
    recorded_at: str = SQLField(default_factory=lambda: datetime.now(timezone.utc).isoformat())


class LotCreate(BaseModel):
    farmer_id: str
    fpo_id: str
    variety_hint: str = ""
    harvest_epoch: int
    field_brix: Optional[float] = Field(default=None, ge=0, le=30)
    field_badge: Optional[str] = None


class GradeCreate(BaseModel):
    lot_id: str
    arrival_brix: float = Field(gt=0, le=30)
    harvest_brix: Optional[float] = Field(default=None, gt=0, le=30)
    dose: Optional[float] = Field(default=None, ge=0)
    transit_hours: float = Field(ge=0)
    status: str = BackcastStatus.OK
    device_id: str
    signature: str


class VerifyRequest(BaseModel):
    """Mirrors the device's gated backcast exactly — including its refusal
    modes. This endpoint exists so a farmer, FPO or regulator can independently
    recompute a disputed grade; it must therefore be able to independently
    recompute a disputed *refusal* too, not only a successful correction."""

    arrival_brix: float = Field(gt=0, le=30)
    tti_response: float = Field(ge=0, le=1)
    declared_transit_hours: float = Field(ge=0)


def get_session():
    with Session(engine) as session:
        yield session


@app.on_event("startup")
def on_startup() -> None:
    SQLModel.metadata.create_all(engine)


# ---------------------------------------------------------------- routes ---
@app.post("/lots", response_model=Lot, status_code=201)
def create_lot(body: LotCreate, s: Session = Depends(get_session)) -> Lot:
    """Register a lot at the field edge and mint its ID."""
    seq = len(s.exec(select(Lot)).all()) + 1
    lot = Lot(lot_id=f"LOT-{datetime.now(timezone.utc):%Y}-{seq:06d}", **body.model_dump())
    s.add(lot)
    s.commit()
    s.refresh(lot)
    return lot


@app.get("/lots/{lot_id}", response_model=Lot)
def get_lot(lot_id: str, s: Session = Depends(get_session)) -> Lot:
    lot = s.get(Lot, lot_id)
    if not lot:
        raise HTTPException(404, "Lot not found")
    return lot


@app.get("/lots/{lot_id}/qr")
def lot_qr(lot_id: str, transit_hours: float = 0.0, s: Session = Depends(get_session)):
    """PNG QR the driver tapes to the trailer. Contains exactly what Mill Mode
    needs offline — no network call at the gate, because the gate has no signal."""
    lot = s.get(Lot, lot_id)
    if not lot:
        raise HTTPException(404, "Lot not found")
    payload = json.dumps({
        "lot_id": lot.lot_id,
        "farmer_id": lot.farmer_id,
        "fpo_id": lot.fpo_id,
        "variety_hint": lot.variety_hint,
        "harvest_epoch": lot.harvest_epoch,
        "transit_hours": transit_hours,
    }, separators=(",", ":"), sort_keys=True)

    img = qrcode.make(payload)
    buf = io.BytesIO()
    img.save(buf, format="PNG")
    buf.seek(0)
    return StreamingResponse(buf, media_type="image/png")


@app.post("/grades", response_model=Grade, status_code=201)
def record_grade(body: GradeCreate, s: Session = Depends(get_session)) -> Grade:
    """Store a device-signed grade — or a device-signed refusal to grade.

    The server stores; it does not decide. A record with
    status != "ok" and harvest_brix == None is not malformed data, it is the
    auditable trace of the device declining to correct a lot per claims 11-13.
    Rejecting it here would defeat the entire purpose of signing refusals.
    """
    if not s.get(Lot, body.lot_id):
        raise HTTPException(404, "Unknown lot")
    if body.status == BackcastStatus.OK and body.harvest_brix is None:
        raise HTTPException(422, "status 'ok' requires a harvest_brix.")
    if body.status != BackcastStatus.OK and body.harvest_brix is not None:
        raise HTTPException(
            422, "A non-OK status must not carry a harvest_brix — that would "
                 "misrepresent an uncorrected reading as a corrected one."
        )
    if body.harvest_brix is not None and body.harvest_brix < body.arrival_brix - 1e-6:
        raise HTTPException(
            422, "Harvest Brix below arrival Brix — sucrose does not increase in transit."
        )
    g = Grade(**body.model_dump())
    s.add(g)
    s.commit()
    s.refresh(g)
    return g


@app.get("/lots/{lot_id}/grades", response_model=list[Grade])
def lot_grades(lot_id: str, s: Session = Depends(get_session)):
    return s.exec(select(Grade).where(Grade.lot_id == lot_id)).all()


@app.post("/verify")
def verify(body: VerifyRequest):
    """Independent recomputation of a backcast, for dispute resolution.

    A farmer, an FPO or a regulator can post the same inputs the device used and
    check both the arithmetic AND the integrity gate themselves. Matching here
    does not prove the *inputs* were honest — that is what the device signature
    is for — but it makes both the correction and any refusal to correct
    auditable rather than a black box behind a payment.
    """
    r = gated_backcast_from_tti(body.arrival_brix, body.tti_response,
                                declared_hours=body.declared_transit_hours)
    return {
        "status": r.status,
        "arrival_brix": r.brix_arrival,
        "harvest_brix": round(r.brix_harvest, 3) if r.brix_harvest is not None else None,
        "interval": [round(v, 3) for v in r.interval] if r.interval else None,
        "dose": round(r.dose, 6) if r.dose is not None else None,
        "implied_hours": round(r.implied_hours, 2) if r.implied_hours is not None else None,
        "declared_hours": r.declared_hours,
        "deviation_hours": round(r.deviation_hours, 2) if r.deviation_hours is not None else None,
        "explanation": r.summary(),
    }


@app.get("/health")
def health():
    return {"status": "ok", "version": app.version}
