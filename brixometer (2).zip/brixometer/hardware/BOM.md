# Bill of materials (indicative, prototype quantities)

Prices are indicative INR for prototype volumes and will differ at scale.
This is a planning document, not a quotation.

| # | Item | Qty | Notes |
|---|---|---|---|
| 1 | ESP32-S3 module (8 MB PSRAM, 16 MB flash) | 1 | PSRAM needed for the RGB frame buffer |
| 2 | Multi-channel spectral sensor (AS7341 / AS7265x class) | 1–2 | Two staggered devices to reach 18 usable channels |
| 3 | Broadband illuminator (tungsten or wide-phosphor LED) | 1 | Spectrum must cover the sugar bands, and be stable |
| 4 | Constant-current lamp driver | 1 | Lamp intensity drift is the dominant field error |
| 5 | Camera module (OV2640/OV5640) | 1 | For the TTI strip and rind texture |
| 6 | Linear polariser film, 2 pcs | 1 set | Crossed pair: source and lens. Kills specular wax glare |
| 7 | PTFE white reference tile | 1 | Mounted in the cap; protect from dirt |
| 8 | NTC thermistor / temperature sensor | 1 | Drives white-reference invalidation |
| 9 | Force sensing resistor (FSR402-class) | 1 | Claim 4: gates reading acceptance to a pressure range |
| 10 | 6-axis IMU (MPU6050/BMI160-class) | 1 | Claim 5: validates device orientation during capture; shares the I2C bus |
| 11 | 128×64 OLED (SSD1306) | 1 | Sunlight legibility is a known weak point — evaluate transflective |
| 12 | Status LEDs (green/yellow/red), high brightness | 3 | The primary output in bright sun |
| 13 | Tactile buttons | 3 | Power, scan, mode |
| 14 | Li-ion 18650 cell, 2500 mAh + protection | 1 | Target 400+ scans/charge |
| 15 | USB-C charge/PD controller | 1 | |
| 16 | microSD socket + card | 1 | Offline record buffer |
| 17 | RTC with backup cell | 1 | Timestamps must survive power loss for custody records |
| 18 | Bayonet/twist-lock attachment ring | 1 | Claim 9: tool-less swap between adapters without disturbing optical alignment |
| 19 | Conical nose adapter (field mode) | 1 | Claim 10: point contact with a standing stem |
| 20 | Flat-faced adapter (mill mode) | 1 | Claim 10: flush contact with a cut billet face |
| 21 | Enclosure, IP54 target | 1 | Houses the attachment ring; standoff geometry is set by whichever adapter is fitted |
| 22 | Optical window (sapphire or hard-coated) | 1 | Cane rind is abrasive |
| 23 | PCB, passives, connectors | 1 set | |


## Design notes that are easy to get wrong

- **Fixed standoff is not optional.** The nose cone must set a repeatable
  distance and angle to the stem. Variable standoff is indistinguishable from
  variable sugar as far as the model is concerned.
- **The white tile will get dirty.** Design for cleaning and for detecting a
  degraded tile, or the reference silently drifts.
- **Cross-polarisation costs light.** Budget the illuminator accordingly rather
  than discovering it at integration.
- **Sunlight legibility.** An SSD1306 is close to unreadable in direct sun.
  The LED badge is the real output; treat the OLED as the technician's view.
