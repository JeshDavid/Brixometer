# Contributing

## Before a PR

```bash
ruff check .
pytest -q
```

## Rules specific to this project

1. **Never widen a claim beyond its evidence.** If a number came from synthetic
   data or lab conditions, say so in the same sentence as the number.
2. **Host/device parity is a correctness property.** Changing
   `ml/preprocessing.py` without the matching change in
   `firmware/src/cmoe_inference.cpp` is a bug even if both compile.
3. **The device must be allowed to refuse.** Do not "improve" the UX by removing
   an abstention path or narrowing an interval. A YELLOW badge is a feature.
4. **Do not let the server compute grades.** The registry stores and verifies;
   the device decides and signs.
5. **Calibration data never touches training.** If you find yourself reusing the
   calibration split, the conformal guarantee is already broken.

## Commit style

`area: short imperative summary`, e.g. `ml: fix SNV edge case on flat spectra`.
