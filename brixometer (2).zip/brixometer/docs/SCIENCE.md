# The science behind Brixometer

This document states what the device assumes, where those assumptions come from,
and — importantly — where they break. If you are reviewing this project for a
grant, a competition or a pilot, this is the honest section.

## 1. Measuring Brix without extracting juice

Brix is nominally a refractometric quantity: dissolved solids in expressed
juice. Brixometer never expresses juice, so it is not measuring Brix directly —
it is **predicting a refractometer reading from diffuse reflectance**.

The physical basis is real. Sucrose has C–H and O–H overtone and combination
absorptions in the near infrared; the second overtone region near 900–1000 nm is
the one an inexpensive silicon-adjacent detector can reach. Water absorbs
strongly nearby, and since sugar and water content are inversely coupled in
maturing cane, the water band is itself informative.

The honest limits of that:

- **This is a correlation, not a direct measurement.** The model learns the
  relationship between reflectance and a refractometer reference. It is only
  valid inside the range of varieties, maturities and conditions in the
  calibration set. Outside that range it will still produce a number — which is
  exactly why the conformal interval and the YELLOW badge exist.
- **18 sparse channels is not a spectrum.** A benchtop NIR gives hundreds of
  contiguous wavelengths. A multi-channel front end gives broad, overlapping
  bands. Expect lower accuracy than published benchtop cane-NIR results, and do
  not cite those results as if they were this device's.
- **Rind is in the way.** Reflectance from an intact stem is dominated by the
  rind and wax layer. Cross-polarised imaging suppresses the specular component,
  and the NIR path is chosen for depth, but internode position, rind thickness
  and surface moisture all matter. Standardise the measurement position.

### Preprocessing rationale

| Step | What it fixes |
|---|---|
| Dark/white referencing | detector dark current, lamp intensity drift, ambient leakage |
| log(1/R) | linearises the concentration-to-signal relationship |
| SNV | multiplicative scatter from stem curvature and probe standoff |
| Savitzky-Golay 1st derivative | residual additive baseline, broad sloping background |
| Standardisation | conditions the network; constants baked into firmware |

Order matters and is fixed in both `ml/preprocessing.py` and
`firmware/src/cmoe_inference.cpp`. Host/device parity is a correctness property,
not a nicety.

## 2. Why a mixture of experts

Varietal differences in rind optics and fibre are large enough that one global
calibration is biased per variety, while per-variety models need a label the
farmer cannot reliably supply. A gated mixture learns soft regimes from the
spectrum itself, so inference needs no variety input.

Failure mode to watch: **expert collapse**, where the gate routes everything to
one expert and the mixture degenerates into a single model with extra
parameters. `evaluate.py` prints per-variety routing shares for exactly this
reason. If every variety shows the same expert dominating, raise
`lambda_balance` or lower the gate temperature.

## 3. Conformal prediction — the part that makes this a decision tool

Split-conformal calibration gives, for exchangeable data:

    P(y ∈ C(x)) ≥ 1 − α

with no distributional assumptions. We use **normalised** scores,
`|y − μ| / σ`, so intervals widen on inputs the model finds hard rather than
being one fixed width.

The guarantee is **marginal**, not conditional. It says 90% of readings are
covered overall; it does not promise 90% for every variety. `evaluate.py`
therefore reports per-variety conditional coverage, and undercoverage on any
variety is a blocking issue, not a footnote.

Exchangeability is what breaks first in the field: a new variety, a new season,
a drifting lamp, a different operator technique. Plan for periodic
recalibration, and treat a sudden shift in mean interval width as a drift alarm.

**The badge logic follows from this.** When the interval straddles the harvest
threshold the device says YELLOW — "I don't know, rescan". The error costs are
asymmetric: a false GREEN costs a farmer a season of sucrose; a false YELLOW
costs them thirty seconds. The rule is biased accordingly, and
`evaluate.py` reports the false-GREEN rate separately as the metric that matters.

## 4. Post-harvest inversion kinetics

Sucrose loss after cutting is dominated by acid/enzymatic inversion into glucose
and fructose, plus residual respiration. Over the 15–45 °C transit window both
are well approximated by first-order kinetics with an Arrhenius rate:

    dS/dt = −k(T)·S ,    k(T) = A·exp(−Eₐ/RT)

Integrating over the actual thermal history gives a dimensionless **thermal
dose** D = ∫k(T(t))dt, and therefore

    S_harvest = S_arrival · exp(D)

Reported activation energies for cane sucrose inversion fall broadly in the
60–95 kJ/mol range depending on variety, juice pH and mechanical damage. The
repo default of 72 kJ/mol is a **lab-fitted placeholder**. Refit it on your own
isothermal hold data with `fit_kinetics()` before any number touches a payment.

### Where this model is weakest

- **First-order is an approximation.** At long transit times and high damage
  levels, microbial dextran formation adds a non-first-order term the model does
  not capture. Treat backcasts beyond ~48 h as unreliable.
- **One lumped Eₐ for a heterogeneous load.** A trailer has a hot surface layer
  and a cooler core. The TTI strip samples one location; that is why the
  reported interval carries a 15% relative dose uncertainty rather than pretending
  to precision.
- **The strip must be matched.** The TTI's own activation energy should be close
  to the cane's, or the coupling factor drifts with temperature profile shape.
  Verify the coupling on paired logger/strip runs before deploying a new strip
  batch.

## 5. What TRL 4 actually means here

Validated in the lab, on a controlled set, under controlled illumination. It
does **not** mean field-validated. The claims that still need field evidence:

1. Accuracy holds across operators, not just the person who built it.
2. Accuracy holds across field illumination, dust, and stem surface moisture.
3. The white reference procedure survives real use by a non-technical operator.
4. The TTI coupling factor holds across a real trailer's thermal profile.
5. Mills and farmers will both accept a signed, interval-bearing grade.

Items 1–3 are Phase 1. Items 4–5 are Phase 2. Nothing in this repository
substitutes for that evidence.
