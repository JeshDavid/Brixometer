# Architecture

## System view

```
  FIELD                          TRANSIT                      MILL GATE
  ───────────────────────        ──────────────────           ─────────────────────
  Brixometer (Field Mode)        QR lot tag on trailer        Brixometer (Mill Mode)
   ├ lamp + PTFE white ref       TTI strip accumulating       ├ scan QR   → lot record
   ├ 18-ch NIR reflectance         thermal dose               ├ scan TTI  → dose D
   ├ cross-polar RGB patch                                    ├ NIR scan  → arrival Brix
   ├ CMoE int8 inference                                      ├ backcast  → harvest Brix
   ├ conformal interval                                       └ Ed25519 signed grade
   └ GREEN / YELLOW / RED                                              │
           │                                                           │
           └──────────────► Lot Registry (FastAPI) ◄───────────────────┘
                              mint lot IDs, QR issue,
                              custody log, signed grades,
                              /verify for dispute resolution
```

## Signal chain (Field Mode)

```
lamp on → 8× integration → average
  → dark reference subtract → white reference divide → reflectance R
  → log(1/R) → SNV → Savitzky-Golay d1
  → concat RGB texture features → standardise
  → CMoE: gate(x) · experts(x) → μ, σ
  → conformal interval  [μ − q̂σ, μ + q̂σ]
  → badge(lo, hi)
```

Every stage can refuse. Saturated channel, stale white reference, interval wider
than `MAX_ACCEPTABLE_INTERVAL_BX` — each returns an explicit failure rather than
a number. This is the single most important design property in the firmware.

## Host/device parity

`ml/preprocessing.py` and `firmware/src/cmoe_inference.cpp` implement the same
transform twice, in two languages. Divergence is silent and destroys accuracy,
so:

- The scaler constants are generated into `firmware/include/cmoe_model.h` by
  `ml/export_tflite.py` — never hand-edited.
- Savitzky-Golay coefficients are hard-coded identically in both.
- `tests/test_parity.py` is the guard; extend it whenever you touch either side.

## Why grading happens on the device, not the server

A server that can recompute a grade can also quietly change one. The device
holds the signing key, computes the grade from inputs it observed directly, and
signs the derivation as well as the result. The registry stores and serves; it
never decides. `/verify` lets any third party recompute the arithmetic
independently, which makes the model auditable without making it alterable.

## Offline-first

Mill gates and cane fields do not have reliable connectivity. Everything needed
for a grade is in the QR payload and the strip; the device works fully offline
and syncs records opportunistically. No network call is ever on the critical
path of a farmer's decision.

## Power budget (target)

| Item | Current | Duty |
|---|---|---|
| ESP32-S3 active + inference | ~85 mA | ~2 s/scan |
| Illuminator | ~180 mA | ~1 s/scan |
| OLED | ~12 mA | idle-on |
| Deep sleep | <80 µA | between scans |

Target: 400+ scans on a 2500 mAh cell. Measure it; do not assume it.
