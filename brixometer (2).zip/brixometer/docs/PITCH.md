# Application / pitch copy

Reusable answers, with character counts, for competition and grant forms.

## Domain

**Main domain:** Precision Agriculture (AgriTech)

**Sub-domains:** Edge AI & Machine Learning · NIR Spectroscopy & Sensor Fusion ·
IoT & Embedded Systems · Food Science & Post-Harvest Technology · Supply Chain
Integrity & AgriFinance

> Brixometer falls under Precision Agriculture (AgriTech) as its main domain,
> with sub-domains spanning Edge AI & Machine Learning, NIR Spectroscopy &
> Sensor Fusion, IoT & Embedded Systems, Food Science & Post-Harvest Technology,
> and Supply Chain Integrity & AgriFinance.

## TRL

Brixometer is at **TRL 4 — Technology Validated in Laboratory**. Core algorithms
(CMoE edge model and Arrhenius TTI backcasting) are developed and validated on a
controlled dataset of 200+ sugarcane stems across 4 varieties, with performance
targets met in a lab/controlled-field setting. Real-world field deployment and
commercial pilots have not yet begun. Full ladder in `ROADMAP.md`.

## Problem (theme: sustainable development)

India's sugarcane sector supports over 50 million farmers and still runs on
guesswork. Farmers cut cane on visual cues — leaf colour, the season calendar, a
neighbour's advice — with no affordable way to measure actual sugar content in
the field. Mistimed harvesting causes sucrose loss, crop inversion and pest
damage, destroying yield and income season after season.

At the mill gate the problem deepens. Cane loses sugar in transit through
heat-driven sucrose inversion — irreversible and outside the farmer's control.
Mills grade and pay on degraded arrival quality, not true harvest quality, with
no fairness mechanism and no traceability in the chain of custody.

The result is a structurally unsustainable value chain: smallholders absorb the
cost of systemic inefficiency, post-harvest loss is normalised, sugar recovery is
suboptimal, and precision remains a privilege of agribusinesses that can afford
₹10 Lakh+ laboratory instruments.

This undermines three SDGs — **SDG 2** (inefficient harvesting reduces food
system productivity), **SDG 8** (unfair grading suppresses farmer income), and
**SDG 9** (the absence of affordable precision tools excludes smallholders from
agricultural innovation).

### 300-character version

> India's 50M+ sugarcane farmers lack affordable tools for precise harvest
> timing, losing ₹5,000–18,000 per season. Mills pay on degraded arrival
> quality, not true harvest Brix, penalising farmers for transit delays.
> Brixometer solves both — field to mill, sustainably.

## Solution (500-character band)

> Brixometer is a handheld AIoT device that solves sugarcane harvest imprecision
> and mill-side unfair grading in one platform. In Field Mode it uses 18-channel
> NIR spectroscopy and cross-polar RGB imaging with a Conformal Mixture of
> Experts edge model on ESP32-S3 to deliver a Green/Yellow/Red harvest-readiness
> badge — no juice extraction, no lab. In Mill Mode it scans a QR lot record and
> TTI thermal strip, applies an Arrhenius backcasting model to reconstruct true
> harvest Brix, and corrects for transit degradation so farmers are paid fairly.
> At ₹22,000 it delivers dual-context precision at 2% of laboratory NIR cost,
> accessible to every farmer producer organisation in India.

## Target users

**Primary — the smallholder sugarcane farmer.** 1–5 acres, ₹1–2 Lakh per season,
no lab access, no data behind their harvest decisions. They lose money every
season by cutting too early, too late, or by receiving mill payments they cannot
dispute. Brixometer gives them a tool they hold in one hand, read in seconds
through a colour badge, and afford through their FPO at ₹100–500 amortised per
farmer.

**Secondary — the mill intake operator.** Responsible for grading incoming lots,
with no mechanism to account for transit-induced degradation, leaving every
grading decision exposed to dispute. Brixometer gives them a tamper-evident,
cryptographically signed, mathematically backcasted grade: auditable and
defensible.

**Extended audience.** FPO managers, cooperative leaders, state agriculture
department officers, agri-input dealers, and precision agriculture researchers.

## What the previous project taught

Building SSMA taught me that real problems demand real domain knowledge, that
hardware and software must evolve together, and that honest teamwork always
produces more reliable results than individual brilliance.

---

## A note on claiming numbers

Every performance figure in a submission should be traceable to a run of
`ml/evaluate.py` on real data. At TRL 4 the defensible framing is "validated in
laboratory on 200+ stems across 4 varieties" — not "field-proven". Reviewers who
know the domain will ask about grouped cross-validation, conditional coverage
and seasonal drift, and a candid answer about what is not yet validated reads far
better than an overclaim that collapses under one question.
