# Calibration dataset specification

`train.py` expects a single CSV. One row per scanned stem.

## Required columns

| Column | Type | Notes |
|---|---|---|
| `ch_01` … `ch_18` | float | Referenced reflectance, 0–1. **Not** raw counts. |
| `brix` | float | Reference value from a calibrated refractometer, °Bx |
| `variety` | string | Used for grouped CV — never as a model input |

## Recommended columns

| Column | Type | Notes |
|---|---|---|
| `rgb_mean_r/g/b`, `rgb_std_g`, `rgb_gr_ratio`, `rgb_edge` | float | From `rgb_texture_features()` |
| `stem_id` | string | Enables per-stem grouping; repeat scans of one stem are not independent samples |
| `internode_index` | int | Which internode was scanned, counted from the base |
| `days_after_planting` | int | Maturity covariate for analysis, not a model input |
| `ambient_temp_c`, `rh_pct` | float | Drift diagnosis |
| `operator_id` | string | Lets you detect operator-technique effects |
| `session_id` | string | Groups scans sharing a white reference |

## Collection protocol

1. **Reference first.** Take the refractometer reading from the same internode
   you scanned, not a neighbouring one, within minutes of the optical scan.
2. **Fixed position.** Always scan the same internode position relative to the
   base. Internode-to-internode sugar gradients are real and large.
3. **Re-reference often.** New white reference every session and after any 5 °C
   temperature move.
4. **Span the range.** Include immature, optimal and over-ripe stems. A dataset
   clustered at 17–19 °Bx produces a model that cannot tell you anything useful,
   no matter how good its R².
5. **Repeat scans, tracked.** Three scans per stem, all recorded, sharing a
   `stem_id`. Never average them before training and never let scans of the same
   stem land on both sides of a split.
6. **Log failures.** Rejected readings are data. Record why they were rejected.

## Minimum viable size

The current 200-stem / 4-variety set supports a lab result at TRL 4. For a field
claim, plan for:

- ≥ 6 varieties (so leave-one-variety-out has something to say)
- ≥ 800 stems total
- ≥ 3 growing locations
- ≥ 2 seasons (this is the one everybody skips, and it is the one that matters)
- ≥ 3 operators

## Leakage traps specific to this project

- **Random splits leak variety.** Use grouped CV. A random split will show you a
  beautiful R² that evaporates in the field.
- **Repeat scans of one stem across a split** is the same leak at a finer grain.
- **Session-correlated references.** If one white reference session happens to
  contain all the high-Brix stems, the model learns the session, not the sugar.
- **Conformal calibration data must not be training data.** `train.py` enforces
  the split; do not "improve" it by reusing samples.
