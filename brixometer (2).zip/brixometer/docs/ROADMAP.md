# TRL roadmap

Brixometer is at **TRL 4 — technology validated in laboratory**.

Core algorithms (CMoE edge model, Arrhenius TTI backcasting) are developed and
validated on a controlled set of 200+ sugarcane stems across 4 varieties, with
performance targets met under lab/controlled-field conditions. Real-world
deployment and commercial pilots have not begun.

| TRL | Stage | Status |
|---|---|---|
| 1 | Basic principles observed | Done |
| 2 | Technology concept formulated | Done |
| 3 | Experimental proof of concept | Done |
| 4 | Validated in laboratory | **Current** |
| 5 | Validated in relevant environment | Phase 1 pilot |
| 6 | Demonstrated in relevant environment | Phase 2 |
| 7 | System prototype demonstrated | Phase 3 |
| 8 | System complete and qualified | Phase 4 |
| 9 | Proven in operational environment | Vision 2028+ |

## Phase 1 — TRL 5 (field validation)

Exit criteria, all of which are falsifiable:

- [ ] 500+ field scans across ≥ 3 FPOs and ≥ 2 districts
- [ ] Field RMSE within 20% of the lab RMSE (if it isn't, the lab number was optimistic)
- [ ] Conditional conformal coverage ≥ 85% on every variety present
- [ ] False-GREEN rate < 1%
- [ ] ≥ 3 operators, with inter-operator RMSE spread < 0.4 °Bx
- [ ] White-reference procedure completed correctly by a non-technical operator
      in ≥ 90% of sessions, unsupervised

## Phase 2 — TRL 6 (mill integration)

- [ ] TTI coupling factor validated on ≥ 50 real trailer runs against loggers
- [ ] Backcast error ≤ 1.5 °Bx over 0–48 h real transit
- [ ] Ed25519 signing moved off the stub and into hardware-protected key storage
- [ ] One mill accepts signed grades in a shadow-mode trial (recorded, not paid on)
- [ ] Dispute workflow exercised end-to-end at least once

## Phase 3 — TRL 7 (pre-production)

- [ ] IP54 enclosure, drop-tested
- [ ] BOM at scale ≤ ₹22,000
- [ ] 400+ scans per charge, measured
- [ ] Two full seasons of drift data; documented recalibration interval
- [ ] Independent third-party accuracy audit

## Phase 4 — TRL 8/9

- [ ] Regulatory/metrology position established for payment-affecting use
- [ ] Manufacturing partner, service and calibration network
- [ ] Multi-crop extension evaluated (the optics generalise; the kinetics do not)

## Known risks

| Risk | Severity | Mitigation |
|---|---|---|
| Lab accuracy does not survive the field | High | Phase 1 is designed to find this out early and cheaply |
| Mills decline to accept corrected grades | High | Shadow-mode trial first; commercial case before contract |
| TTI supply and batch consistency | Medium | Qualify two suppliers; per-batch coupling calibration |
| Seasonal/varietal drift | Medium | Drift alarm on interval width; documented recalibration |
| Payment-affecting use attracts metrology regulation | Medium | Engage early; position as decision support until qualified |
| Signing stub shipped by accident | High | Blocking checklist item before any field unit leaves |
