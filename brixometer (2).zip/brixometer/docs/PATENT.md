# Patent reference

Brixometer is the subject of a filed Indian patent application
(Form 2, Complete Specification, under the Patents Act 1970 / Patents Rules 2003):

> **BRIXOMETER — A handheld dual-context device and method for prediction of
> optimum sugarcane maturity using conformal mixture-of-experts spectro-visual
> sensing and Arrhenius-bounded time-temperature backcasting**

The application lists multiple co-inventors from the founding team; individual
addresses are omitted here for privacy. This repository implements the
**software half** of that specification — the embedded firmware logic, the ML
pipeline, and the backend registry — written by **Jeshwin David C**. The
mechanical design (housing, bayonet adapter mount, sensor board layout) is
covered by the same filing and is not reproduced here beyond what the firmware
needs to model correctly (pin roles, sensor gating logic).

## Mapping repo code to the filed claims

| Claim | What it requires | Where it lives in this repo |
|---|---|---|
| 1–3 | Measurement head with NIR board + cross-polar camera behind an LED ring | `ml/preprocessing.py` (fusion), `firmware/src/nir_sensor.cpp` |
| 4 | Force sensor gates reading acceptance to a pressure range | `firmware/src/contact_gate.{h,cpp}` |
| 5 | Orientation sensor validates device orientation during capture | `firmware/src/contact_gate.{h,cpp}` |
| 7 | Router network selects a variety-specific expert sub-model | `ml/cmoe_model.py` (`Gate`, `MixtureOfExperts`) |
| 8 | Conformal prediction layer assigns a GREEN/YELLOW/RED badge from interval width | `ml/conformal.py`, `firmware/src/cmoe_inference.cpp` |
| 9–10 | Tool-less adapter swap between conical (field) and flat-faced (mill) tips | `firmware/include/config.h` (mode/adapter constants); mechanical part not modelled in software |
| 11 | Camera scans a QR (harvest timestamp) and TTI label (exposure) at the mill | `firmware/src/lot_record.cpp` (QR), `firmware/src/tti_decode.cpp` (TTI) |
| 12 | Cross-validate the two before enabling any correction | `firmware/src/tti_decode.cpp::backcast()`, mirrored in `ml/arrhenius_tti.py::gated_backcast_from_tti()` |
| 13 | Apply Arrhenius-bounded backcast only within declared bounds; disable outright otherwise | same two functions — see `BackcastStatus` |
| 14 | Wireless module for optional sync, core prediction stays offline | `backend/app.py` (registry the module would sync to); on-device sync client not yet implemented |

## Why the gate matters more than the arithmetic

Claims 12–13 are not a nice-to-have — they are the difference between a
device that estimates a number and one that is trustworthy enough to sit
between a farmer's crop and their payment. `gated_backcast_from_tti()` and its
firmware mirror will *never* return a corrected Brix figure unless the QR's
declared transit time and the TTI's own implied transit time agree within
tolerance, and the exposure is within a bound the model is trusted for. Outside
that, the function returns a signed refusal, not a guess — see
`tests/test_arrhenius.py::TestGatedBackcast`.

## A note on scope

This document describes what the patent claims and what this repository
implements toward them; it is not legal advice, and nothing here should be
read as an assertion of granted patent rights. Check the applicant record
directly if you need the authoritative filing status.
