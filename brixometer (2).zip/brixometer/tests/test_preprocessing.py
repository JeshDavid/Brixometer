import sys
from pathlib import Path

import numpy as np
import pytest

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "ml"))

from preprocessing import (  # noqa: E402
    N_CHANNELS, StandardScaler, absorbance, build_features, reference_correct,
    rgb_texture_features, sg_derivative, snv,
)


def test_reference_correct_bounds():
    raw = np.array([500.0] * N_CHANNELS)
    dark = np.array([50.0] * N_CHANNELS)
    white = np.array([1000.0] * N_CHANNELS)
    R = reference_correct(raw, dark, white)
    assert np.allclose(R, (500 - 50) / (1000 - 50))


def test_reference_rejects_bad_white():
    with pytest.raises(ValueError):
        reference_correct(np.ones(N_CHANNELS), np.ones(N_CHANNELS) * 2,
                          np.ones(N_CHANNELS))


def test_snv_removes_multiplicative_scatter():
    base = np.linspace(0.2, 0.8, N_CHANNELS)[None, :]
    scaled = base * 1.7
    assert np.allclose(snv(base), snv(scaled), atol=1e-8)


def test_absorbance_is_monotonic_decreasing_in_reflectance():
    a = absorbance(np.array([0.2, 0.5, 0.9]))
    assert a[0] > a[1] > a[2]


def test_sg_derivative_of_constant_is_zero():
    X = np.ones((3, N_CHANNELS))
    assert np.allclose(sg_derivative(X), 0.0, atol=1e-8)


def test_sg_rejects_even_window():
    with pytest.raises(ValueError):
        sg_derivative(np.ones((1, N_CHANNELS)), window=4)


def test_rgb_features_shape_and_range():
    patch = (np.random.default_rng(0).random((16, 16, 3)) * 255)
    f = rgb_texture_features(patch)
    assert f.shape == (6,)
    assert np.all(np.isfinite(f))


def test_build_features_dimension():
    refl = np.random.default_rng(0).uniform(0.2, 0.8, (5, N_CHANNELS))
    rgb = np.zeros((5, 6))
    X = build_features(refl, rgb)
    assert X.shape == (5, 2 * N_CHANNELS + 6)


def test_scaler_round_trip():
    X = np.random.default_rng(1).normal(5, 3, (50, 4))
    Z = StandardScaler().fit_transform(X)
    assert np.allclose(Z.mean(0), 0, atol=1e-8)
    assert np.allclose(Z.std(0), 1, atol=1e-8)
