import sys
from pathlib import Path

import numpy as np
import pytest

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "ml"))

from conformal import (  # noqa: E402
    ConformalCalibrator, GREEN, RED, YELLOW, badge_with_reason, readiness_badge,
)


class TestCoverage:
    def test_marginal_coverage_holds(self):
        rng = np.random.default_rng(1)
        n = 2000
        sigma = rng.uniform(0.5, 1.5, n)
        mu = rng.normal(18, 2, n)
        y = mu + rng.normal(0, 1, n) * sigma

        cal = ConformalCalibrator(alpha=0.10).fit(y[:1000], mu[:1000], sigma[:1000])
        cov = cal.coverage(y[1000:], mu[1000:], sigma[1000:])
        assert cov >= 0.86   # finite-sample slack around the 0.90 target

    def test_tighter_alpha_widens_intervals(self):
        rng = np.random.default_rng(2)
        n = 500
        sigma = np.ones(n)
        mu = rng.normal(18, 2, n)
        y = mu + rng.normal(0, 1, n)
        wide = ConformalCalibrator(alpha=0.01).fit(y, mu, sigma)
        narrow = ConformalCalibrator(alpha=0.20).fit(y, mu, sigma)
        assert wide.q_hat > narrow.q_hat

    def test_tiny_calibration_set_rejected(self):
        with pytest.raises(ValueError):
            ConformalCalibrator().fit(np.ones(5), np.ones(5), np.ones(5))

    def test_unfitted_calibrator_raises(self):
        with pytest.raises(RuntimeError):
            ConformalCalibrator().interval(np.array([1.0]), np.array([1.0]))


class TestBadge:
    def test_confident_in_window_is_green(self):
        assert readiness_badge(18.5, 20.0) == GREEN

    def test_confident_below_window_is_red(self):
        assert readiness_badge(14.0, 16.0) == RED

    def test_confident_above_window_is_red(self):
        assert readiness_badge(22.0, 23.5) == RED

    def test_straddling_threshold_is_yellow(self):
        assert readiness_badge(17.5, 18.6) == YELLOW

    def test_wide_interval_abstains(self):
        # A device that knows nothing must not produce a confident badge.
        assert readiness_badge(12.0, 24.0) == YELLOW

    def test_reversed_interval_rejected(self):
        with pytest.raises(ValueError):
            readiness_badge(20.0, 18.0)

    def test_reason_accompanies_every_badge(self):
        for lo, hi in [(18.5, 20.0), (14.0, 16.0), (22.0, 23.0), (17.6, 18.4)]:
            badge, reason = badge_with_reason(lo, hi)
            assert badge in {GREEN, YELLOW, RED}
            assert len(reason) > 10
