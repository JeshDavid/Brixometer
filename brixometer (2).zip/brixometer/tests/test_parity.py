"""
Host/device preprocessing parity.

The firmware reimplements ml/preprocessing.py in C++. Any divergence is silent
and destroys accuracy in the field, so the C++ arithmetic is mirrored here in
Python and checked against the reference implementation.

If you change either side, change this file too — and if you can build the
firmware's native test env, extend firmware tests to load the same fixtures.
"""

import sys
from pathlib import Path

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "ml"))

from preprocessing import N_CHANNELS, absorbance, sg_derivative, snv  # noqa: E402


def cpp_absorbance_snv(R: np.ndarray) -> np.ndarray:
    """Mirror of absorbanceSnv() in firmware/src/cmoe_inference.cpp.

    Note the deliberate difference from numpy's default: the C++ code divides
    by the population standard deviation (ddof=0), which is what
    preprocessing.snv() also does. That agreement is the point of this test.
    """
    a = np.log10(1.0 / np.maximum(R, 1e-4))
    mean = a.mean()
    sd = np.sqrt(((a - mean) ** 2).sum() / a.size)
    if sd < 1e-8:
        sd = 1.0
    return (a - mean) / sd


def cpp_sg_deriv1(x: np.ndarray) -> np.ndarray:
    """Mirror of sgDeriv1() in firmware/src/cmoe_inference.cpp."""
    c = np.array([-0.2, -0.1, 0.0, 0.1, 0.2])
    n = x.size
    out = np.empty(n)
    for i in range(n):
        base = min(max(i - 2, 0), n - 5)
        out[i] = float(np.dot(c, x[base:base + 5]))
    return out


def test_absorbance_snv_matches_host():
    rng = np.random.default_rng(3)
    R = rng.uniform(0.15, 0.85, N_CHANNELS)
    host = snv(absorbance(R))[0]
    device = cpp_absorbance_snv(R)
    assert np.allclose(host, device, atol=1e-10)


def test_snv_is_population_sd_on_both_sides():
    R = np.linspace(0.2, 0.8, N_CHANNELS)
    assert np.allclose(snv(absorbance(R))[0], cpp_absorbance_snv(R), atol=1e-10)


def test_sg_derivative_interior_matches_host():
    rng = np.random.default_rng(4)
    x = rng.normal(0, 1, N_CHANNELS)
    host = sg_derivative(x[None, :], order=1, window=5, poly=2)[0]
    device = cpp_sg_deriv1(x)
    # Interior points must match exactly; scipy handles edges differently, which
    # is a known and accepted divergence documented in docs/ARCHITECTURE.md.
    assert np.allclose(host[2:-2], device[2:-2], atol=1e-8)


def test_sg_derivative_edges_are_documented_divergence():
    rng = np.random.default_rng(5)
    x = rng.normal(0, 1, N_CHANNELS)
    host = sg_derivative(x[None, :], order=1, window=5, poly=2)[0]
    device = cpp_sg_deriv1(x)
    edge_gap = np.max(np.abs(host[:2] - device[:2]))
    # Guard against the gap silently growing if either side changes.
    assert edge_gap < 2.0, "Edge handling has diverged further than expected."
