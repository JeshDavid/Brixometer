import sys
from pathlib import Path

import numpy as np
import pytest

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "ml"))

from arrhenius_tti import (  # noqa: E402
    DEFAULT_PARAMS, KineticParams, TTICalibration, backcast_brix,
    backcast_from_logger, backcast_from_tti, effective_temperature,
    fit_kinetics, thermal_dose_from_trace, thermal_dose_isothermal,
)


class TestKinetics:
    def test_rate_increases_with_temperature(self):
        assert DEFAULT_PARAMS.k(40) > DEFAULT_PARAMS.k(25)

    def test_q10_is_physically_plausible(self):
        # A ~72 kJ/mol activation energy should roughly double-to-triple the
        # rate per 10 C. If this fails the parameters are unphysical.
        ratio = DEFAULT_PARAMS.k(40) / DEFAULT_PARAMS.k(30)
        assert 1.8 < ratio < 3.5

    def test_absolute_zero_rejected(self):
        with pytest.raises(ValueError):
            DEFAULT_PARAMS.k(-300)


class TestDose:
    def test_isothermal_matches_trace(self):
        d_iso = thermal_dose_isothermal(10.0, 35.0)
        t = np.linspace(0, 10, 200)
        d_trace = thermal_dose_from_trace(t, np.full_like(t, 35.0))
        assert d_iso == pytest.approx(d_trace, rel=1e-6)

    def test_trace_requires_increasing_time(self):
        with pytest.raises(ValueError):
            thermal_dose_from_trace([0, 2, 1], [30, 30, 30])

    def test_effective_temperature_round_trips(self):
        d = thermal_dose_isothermal(12.0, 37.0)
        assert effective_temperature(d, 12.0) == pytest.approx(37.0, abs=1e-6)


class TestBackcast:
    def test_zero_dose_is_identity(self):
        r = backcast_brix(17.0, 0.0)
        assert r.brix_harvest == pytest.approx(17.0)
        assert r.loss_bx == pytest.approx(0.0)

    def test_harvest_exceeds_arrival(self):
        r = backcast_from_tti(16.5, 0.25, hours=12.0)
        assert r.brix_harvest > r.brix_arrival
        assert r.loss_pct > 0

    def test_interval_brackets_point_estimate(self):
        r = backcast_from_tti(16.5, 0.30, hours=12.0)
        lo, hi = r.interval
        assert lo <= r.brix_harvest <= hi

    def test_interval_is_asymmetric(self):
        # The correction is multiplicative, so the band must not be symmetric.
        r = backcast_from_tti(16.0, 0.45, hours=20.0)
        lo, hi = r.interval
        assert (hi - r.brix_harvest) > (r.brix_harvest - lo)

    def test_longer_transit_means_larger_correction(self):
        short = backcast_brix(16.0, thermal_dose_isothermal(4.0, 35.0))
        long_ = backcast_brix(16.0, thermal_dose_isothermal(24.0, 35.0))
        assert long_.brix_harvest > short.brix_harvest

    def test_logger_intervals_are_tighter_than_tti(self):
        hours = np.linspace(0, 12, 50)
        temps = np.full_like(hours, 34.0)
        lg = backcast_from_logger(16.0, hours, temps)
        tt = backcast_from_tti(16.0, 1 - np.exp(-lg.dose), hours=12.0)
        w_lg = lg.interval[1] - lg.interval[0]
        w_tt = tt.interval[1] - tt.interval[0]
        assert w_lg < w_tt

    def test_saturated_strip_is_flagged(self):
        r = backcast_from_tti(16.0, 0.995, hours=30.0)
        assert r.saturated is True

    def test_negative_brix_rejected(self):
        with pytest.raises(ValueError):
            backcast_brix(-1.0, 0.1)


class TestFitting:
    def test_recovers_known_parameters(self):
        true = KineticParams(ln_A=24.0, Ea=70_000.0)
        rng = np.random.default_rng(0)
        temps, hours, S0, S1 = [], [], [], []
        for T in (22.0, 28.0, 35.0, 42.0):
            for h in (6.0, 12.0, 24.0):
                s0 = float(rng.uniform(16, 20))
                s1 = s0 * float(np.exp(-true.k(T) * h))
                temps.append(T); hours.append(h); S0.append(s0); S1.append(s1)
        fitted = fit_kinetics(S0, S1, hours, temps)
        assert fitted.Ea == pytest.approx(true.Ea, rel=0.02)
        assert fitted.ln_A == pytest.approx(true.ln_A, rel=0.02)


class TestTTICalibration:
    def test_response_to_dose_is_monotonic(self):
        cal = TTICalibration()
        assert cal.dose(0.6) > cal.dose(0.3)

    def test_out_of_range_response_rejected(self):
        with pytest.raises(ValueError):
            TTICalibration().dose(1.4)


class TestGatedBackcast:
    """Claims 11-13: QR/TTI cross-validation must gate the correction — no
    fallback estimate is permitted when the check fails."""

    def test_agreeing_signals_apply_correction(self):
        from arrhenius_tti import (BackcastStatus, DEFAULT_PARAMS,
                                    gated_backcast_from_tti)
        # Construct a dose that, at the 33C reference, implies ~14h — matching
        # a QR that declares 14h transit.
        dose = DEFAULT_PARAMS.k(33.0) * 14.0
        response = 1 - np.exp(-dose)
        r = gated_backcast_from_tti(16.5, response, declared_hours=14.0)
        assert r.status == BackcastStatus.OK
        assert r.brix_harvest is not None
        assert r.brix_harvest > r.brix_arrival

    def test_disagreeing_signals_disable_correction(self):
        from arrhenius_tti import BackcastStatus, gated_backcast_from_tti
        # TTI implies a very different exposure than the QR declares — tamper
        # or substitution signature.
        r = gated_backcast_from_tti(16.5, tti_response=0.9, declared_hours=1.0)
        assert r.status == BackcastStatus.INTEGRITY_MISMATCH
        assert r.brix_harvest is None

    def test_exceeded_exposure_disables_correction_even_if_consistent(self):
        from arrhenius_tti import (BackcastStatus, DEFAULT_PARAMS,
                                    gated_backcast_from_tti)
        hours = 60.0  # beyond the 48h trust bound
        dose = DEFAULT_PARAMS.k(33.0) * hours
        response = 1 - np.exp(-dose)
        r = gated_backcast_from_tti(16.5, response, declared_hours=hours)
        assert r.status == BackcastStatus.EXPOSURE_EXCEEDED
        assert r.brix_harvest is None

    def test_saturated_strip_is_unreadable_not_estimated(self):
        from arrhenius_tti import BackcastStatus, gated_backcast_from_tti
        r = gated_backcast_from_tti(16.5, tti_response=0.995, declared_hours=10.0)
        assert r.status == BackcastStatus.TTI_UNREADABLE
        assert r.brix_harvest is None

    def test_never_silently_estimates_on_any_failure(self):
        """No code path in the gated function may return a numeric
        brix_harvest unless status is OK — this is the property the whole
        gate exists to guarantee."""
        from arrhenius_tti import BackcastStatus, gated_backcast_from_tti
        cases = [
            (16.0, 0.995, 10.0),   # unreadable
            (16.0, 0.5, 0.1),      # mismatch (huge implied vs tiny declared)
            (16.0, 0.97, 200.0),   # exceeded
        ]
        for arrival, resp, hours in cases:
            r = gated_backcast_from_tti(arrival, resp, declared_hours=hours)
            if r.status != BackcastStatus.OK:
                assert r.brix_harvest is None
