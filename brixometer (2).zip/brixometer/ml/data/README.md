# Data

`raw/` is git-ignored. Real calibration spectra do not belong in a public repo —
they carry farm location, farmer identity and commercially sensitive yield
information. Use DVC, a release asset, or an institutional data store, and keep
a checksum here.

Schema: see `docs/DATA_SPEC.md`.

Generate a runnable synthetic stand-in with:

```bash
python scripts/make_synthetic_dataset.py --n 600 --out ml/data/raw/synthetic.csv
```

Synthetic data is scaffolding. No result computed from it is a validation
result, and none should appear in a pitch, a paper or a grant application.
