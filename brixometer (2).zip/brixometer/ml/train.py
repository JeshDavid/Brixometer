"""
End-to-end CMoE training with variety-grouped cross-validation.

Run:
    python ml/train.py --data ml/data/raw/calibration.csv --out ml/artifacts

Splitting is *grouped by variety* on purpose. A random split leaks variety
identity across folds and inflates R^2 by a wide margin — the model memorises
the four varieties rather than learning sugar. Leave-one-variety-out tells you
what actually happens when the device meets a fifth variety in the field.
"""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
import pandas as pd
import torch
from torch.utils.data import DataLoader, TensorDataset

import sys
sys.path.insert(0, str(Path(__file__).resolve().parent))

from cmoe_model import MixtureOfExperts, cmoe_loss, predict  # noqa: E402
from conformal import ConformalCalibrator  # noqa: E402
from preprocessing import StandardScaler, build_features  # noqa: E402

SPECTRAL_COLS = [f"ch_{i:02d}" for i in range(1, 19)]
RGB_COLS = ["rgb_mean_r", "rgb_mean_g", "rgb_mean_b",
            "rgb_std_g", "rgb_gr_ratio", "rgb_edge"]
TARGET_COL = "brix"
GROUP_COL = "variety"


def load_dataset(path: Path) -> tuple[np.ndarray, np.ndarray, np.ndarray]:
    df = pd.read_csv(path)
    missing = [c for c in SPECTRAL_COLS + [TARGET_COL, GROUP_COL] if c not in df.columns]
    if missing:
        raise ValueError(f"Missing required columns: {missing}. See docs/DATA_SPEC.md")

    refl = df[SPECTRAL_COLS].to_numpy(float)
    rgb = df[RGB_COLS].to_numpy(float) if all(c in df.columns for c in RGB_COLS) else None
    X = build_features(refl, rgb)
    y = df[TARGET_COL].to_numpy(float)
    groups = df[GROUP_COL].to_numpy()

    if np.isnan(X).any() or np.isnan(y).any():
        raise ValueError("NaNs in features or target — clean the dataset first.")
    return X, y, groups


def train_one(
    X_tr: np.ndarray, y_tr: np.ndarray,
    X_va: np.ndarray, y_va: np.ndarray,
    *, n_experts: int, epochs: int, lr: float, batch_size: int, seed: int,
) -> tuple[MixtureOfExperts, dict]:
    torch.manual_seed(seed)
    model = MixtureOfExperts(in_dim=X_tr.shape[1], n_experts=n_experts)
    opt = torch.optim.AdamW(model.parameters(), lr=lr, weight_decay=1e-4)
    sched = torch.optim.lr_scheduler.CosineAnnealingLR(opt, T_max=epochs)

    ds = TensorDataset(torch.tensor(X_tr, dtype=torch.float32),
                       torch.tensor(y_tr, dtype=torch.float32))
    dl = DataLoader(ds, batch_size=batch_size, shuffle=True, drop_last=False)

    Xv = torch.tensor(X_va, dtype=torch.float32)
    best = {"rmse": float("inf"), "state": None, "epoch": -1}

    for ep in range(epochs):
        model.train()
        for xb, yb in dl:
            opt.zero_grad()
            mu, sigma, w, preds = model(xb)
            loss, _ = cmoe_loss(mu, sigma, w, preds, yb)
            loss.backward()
            torch.nn.utils.clip_grad_norm_(model.parameters(), 1.0)
            opt.step()
        sched.step()

        mu_v, _, _ = predict(model, Xv)
        rmse = float(np.sqrt(np.mean((mu_v - y_va) ** 2)))
        if rmse < best["rmse"]:
            best = {"rmse": rmse,
                    "state": {k: v.clone() for k, v in model.state_dict().items()},
                    "epoch": ep}

    model.load_state_dict(best["state"])
    return model, {"val_rmse": best["rmse"], "best_epoch": best["epoch"]}


def main() -> None:
    ap = argparse.ArgumentParser(description="Train the Brixometer CMoE model.")
    ap.add_argument("--data", type=Path, required=True)
    ap.add_argument("--out", type=Path, default=Path("ml/artifacts"))
    ap.add_argument("--n-experts", type=int, default=4)
    ap.add_argument("--epochs", type=int, default=300)
    ap.add_argument("--lr", type=float, default=3e-3)
    ap.add_argument("--batch-size", type=int, default=32)
    ap.add_argument("--alpha", type=float, default=0.10,
                    help="1 - target coverage for conformal intervals")
    ap.add_argument("--seed", type=int, default=42)
    args = ap.parse_args()

    args.out.mkdir(parents=True, exist_ok=True)
    X, y, groups = load_dataset(args.data)
    uniq = np.unique(groups)
    print(f"Loaded {len(y)} samples, {X.shape[1]} features, varieties: {list(uniq)}")

    # ---- Leave-one-variety-out CV: the honest generalisation estimate -------
    cv_report = {}
    for v in uniq:
        te = groups == v
        tr = ~te
        scaler = StandardScaler().fit(X[tr])
        m, info = train_one(
            scaler.transform(X[tr]), y[tr], scaler.transform(X[te]), y[te],
            n_experts=args.n_experts, epochs=args.epochs, lr=args.lr,
            batch_size=args.batch_size, seed=args.seed,
        )
        mu, _, _ = predict(m, torch.tensor(scaler.transform(X[te]), dtype=torch.float32))
        rmse = float(np.sqrt(np.mean((mu - y[te]) ** 2)))
        bias = float(np.mean(mu - y[te]))
        cv_report[str(v)] = {"n": int(te.sum()), "rmse": rmse, "bias": bias}
        print(f"  held-out {v}: RMSE={rmse:.3f}  bias={bias:+.3f}  (n={te.sum()})")

    # ---- Final model: train / calibrate split over all varieties -----------
    rng = np.random.default_rng(args.seed)
    idx = rng.permutation(len(y))
    n_cal = max(30, int(0.2 * len(y)))
    cal_idx, fit_idx = idx[:n_cal], idx[n_cal:]
    n_val = max(20, int(0.15 * len(fit_idx)))
    val_idx, tr_idx = fit_idx[:n_val], fit_idx[n_val:]

    scaler = StandardScaler().fit(X[tr_idx])
    model, info = train_one(
        scaler.transform(X[tr_idx]), y[tr_idx],
        scaler.transform(X[val_idx]), y[val_idx],
        n_experts=args.n_experts, epochs=args.epochs, lr=args.lr,
        batch_size=args.batch_size, seed=args.seed,
    )

    Xc = torch.tensor(scaler.transform(X[cal_idx]), dtype=torch.float32)
    mu_c, sg_c, _ = predict(model, Xc)
    calib = ConformalCalibrator(alpha=args.alpha).fit(y[cal_idx], mu_c, sg_c)
    print(f"Conformal q_hat={calib.q_hat:.3f} on n={calib.n_calib}; "
          f"empirical coverage={calib.coverage(y[cal_idx], mu_c, sg_c):.3f}")

    torch.save(model.state_dict(), args.out / "cmoe.pt")
    np.savez(args.out / "scaler.npz", mean=scaler.mean_, scale=scaler.scale_)
    (args.out / "config.json").write_text(json.dumps({
        "in_dim": int(X.shape[1]),
        "n_experts": args.n_experts,
        "alpha": args.alpha,
        "q_hat": calib.q_hat,
        "n_calib": calib.n_calib,
        "val_rmse": info["val_rmse"],
        "leave_one_variety_out": cv_report,
        "spectral_cols": SPECTRAL_COLS,
        "rgb_cols": RGB_COLS,
    }, indent=2))
    np.savez(args.out / "calib_split.npz", cal_idx=cal_idx, val_idx=val_idx, tr_idx=tr_idx)
    print(f"Artifacts written to {args.out}")


if __name__ == "__main__":
    main()
