"""
Split-conformal calibration: turns a point predictor into a predictor with
finite-sample, distribution-free coverage guarantees.

Why this matters for Brixometer specifically
--------------------------------------------
A farmer acting on "17.2 °Bx" is acting on a number with no stated risk. A
farmer acting on "17.2 °Bx, and we are 90% confident the true value is in
[16.4, 18.0]" can make a harvest decision proportionate to what the device
actually knows. When the interval straddles the harvest threshold, the badge
goes YELLOW — 'wait and rescan' — rather than guessing Green or Red.

That is the entire ethical argument for the 'C' in CMoE: the device is allowed
to say it does not know.

Guarantee
---------
For exchangeable data and a calibration set of size n, the interval built from
the ceil((n+1)(1-alpha))-th smallest normalised residual satisfies

    P(y in C(x)) >= 1 - alpha

marginally. Exchangeability is the assumption that breaks first in the field
(new variety, new season, drifting lamp), so evaluate.py reports *conditional*
coverage per variety, not just the marginal number.
"""

from __future__ import annotations

from dataclasses import dataclass

import numpy as np


@dataclass
class ConformalCalibrator:
    """Normalised split-conformal calibrator.

    Score: s_i = |y_i - mu_i| / sigma_i
    Interval: mu +/- q_hat * sigma
    """

    alpha: float = 0.10
    q_hat: float | None = None
    n_calib: int = 0

    def fit(self, y_true: np.ndarray, mu: np.ndarray, sigma: np.ndarray) -> "ConformalCalibrator":
        y_true, mu, sigma = map(lambda a: np.asarray(a, float).ravel(), (y_true, mu, sigma))
        if not (y_true.shape == mu.shape == sigma.shape):
            raise ValueError("Shapes of y_true, mu and sigma must match.")
        if np.any(sigma <= 0):
            raise ValueError("sigma must be strictly positive.")

        n = y_true.size
        if n < 20:
            raise ValueError(
                f"Calibration set of {n} is too small for a meaningful guarantee; "
                "use at least 20, ideally 100+."
            )

        scores = np.abs(y_true - mu) / sigma
        level = np.ceil((n + 1) * (1.0 - self.alpha)) / n
        if level > 1.0:
            raise ValueError(
                f"alpha={self.alpha} is too small for n={n}; "
                f"need n >= {int(np.ceil(1 / self.alpha)) - 1}."
            )
        self.q_hat = float(np.quantile(scores, level, method="higher"))
        self.n_calib = int(n)
        return self

    def interval(self, mu: np.ndarray, sigma: np.ndarray) -> tuple[np.ndarray, np.ndarray]:
        if self.q_hat is None:
            raise RuntimeError("Calibrator not fitted.")
        mu = np.asarray(mu, float)
        sigma = np.asarray(sigma, float)
        half = self.q_hat * sigma
        return mu - half, mu + half

    def coverage(self, y_true: np.ndarray, mu: np.ndarray, sigma: np.ndarray) -> float:
        lo, hi = self.interval(mu, sigma)
        y_true = np.asarray(y_true, float)
        return float(np.mean((y_true >= lo) & (y_true <= hi)))

    def mean_width(self, sigma: np.ndarray) -> float:
        if self.q_hat is None:
            raise RuntimeError("Calibrator not fitted.")
        return float(2.0 * self.q_hat * np.mean(np.asarray(sigma, float)))


# --------------------------------------------------------------------------- #
# Badge decision
# --------------------------------------------------------------------------- #
GREEN, YELLOW, RED = "GREEN", "YELLOW", "RED"


def readiness_badge(
    lo: float,
    hi: float,
    *,
    ready_threshold: float = 18.0,
    over_threshold: float = 21.0,
) -> str:
    """Map a conformal interval to the field badge.

    GREEN  — the whole interval sits in the harvest window: cut now.
    RED    — the whole interval sits below the window (immature) or above it
             (over-ripe / inverting): do not cut now.
    YELLOW — the interval straddles a threshold: the device is not confident.
             Wait and rescan, or take more stems.

    Note the asymmetry of consequence: a false GREEN costs the farmer a season's
    sucrose, a false YELLOW costs them a rescan. The rule is deliberately biased
    towards YELLOW.
    """
    if lo > hi:
        raise ValueError("Interval bounds are reversed.")
    if lo >= ready_threshold and hi <= over_threshold:
        return GREEN
    if hi < ready_threshold or lo > over_threshold:
        return RED
    return YELLOW


def badge_with_reason(lo: float, hi: float, **kw) -> tuple[str, str]:
    badge = readiness_badge(lo, hi, **kw)
    ready = kw.get("ready_threshold", 18.0)
    over = kw.get("over_threshold", 21.0)
    if badge == GREEN:
        reason = "Sucrose is in the optimal harvest window with high confidence."
    elif badge == RED and hi < ready:
        reason = f"Sucrose is below the {ready:.0f} °Bx harvest threshold — the crop is still maturing."
    elif badge == RED:
        reason = f"Sucrose is above {over:.0f} °Bx — risk of inversion and pest damage. Harvest immediately."
    else:
        reason = "The reading is too uncertain to call. Rescan, or measure more stems."
    return badge, reason
