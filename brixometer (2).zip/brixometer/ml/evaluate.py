"""
Evaluation and diagnostics.

Reports the metrics a chemometrics reviewer will ask for (RMSE, R^2, SEP, RPD,
bias) plus the ones that matter for a *decision device* and are usually missing:
conditional conformal coverage per variety, badge confusion, and the rate at
which the device declines to answer.

    python ml/evaluate.py --artifacts ml/artifacts --data ml/data/raw/calibration.csv
"""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
import torch

import sys
sys.path.insert(0, str(Path(__file__).resolve().parent))

from cmoe_model import MixtureOfExperts, predict  # noqa: E402
from conformal import ConformalCalibrator, badge_with_reason  # noqa: E402
from train import load_dataset  # noqa: E402


def regression_metrics(y: np.ndarray, yhat: np.ndarray) -> dict:
    resid = yhat - y
    rmse = float(np.sqrt(np.mean(resid ** 2)))
    bias = float(np.mean(resid))
    sep = float(np.std(resid, ddof=1))            # standard error of prediction
    ss_res = float(np.sum(resid ** 2))
    ss_tot = float(np.sum((y - y.mean()) ** 2))
    r2 = 1.0 - ss_res / ss_tot if ss_tot > 0 else float("nan")
    rpd = float(np.std(y, ddof=1) / sep) if sep > 0 else float("inf")
    return {"rmse": rmse, "bias": bias, "sep": sep, "r2": r2, "rpd": rpd,
            "mae": float(np.mean(np.abs(resid)))}


def interpret_rpd(rpd: float) -> str:
    if rpd < 2.0:
        return "poor — screening only, not quantitative"
    if rpd < 2.5:
        return "fair — rough quantification"
    if rpd < 3.0:
        return "good — acceptable for decision support"
    return "excellent — quantitative"


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--artifacts", type=Path, default=Path("ml/artifacts"))
    ap.add_argument("--data", type=Path, required=True)
    ap.add_argument("--ready-threshold", type=float, default=18.0)
    ap.add_argument("--over-threshold", type=float, default=21.0)
    args = ap.parse_args()

    cfg = json.loads((args.artifacts / "config.json").read_text())
    sc = np.load(args.artifacts / "scaler.npz")
    X, y, groups = load_dataset(args.data)
    Xs = (X - sc["mean"]) / sc["scale"]

    model = MixtureOfExperts(in_dim=cfg["in_dim"], n_experts=cfg["n_experts"])
    model.load_state_dict(torch.load(args.artifacts / "cmoe.pt", map_location="cpu"))

    mu, sigma, w = predict(model, torch.tensor(Xs, dtype=torch.float32))

    calib = ConformalCalibrator(alpha=cfg["alpha"], q_hat=cfg["q_hat"],
                                n_calib=cfg["n_calib"])
    lo, hi = calib.interval(mu, sigma)

    print("=" * 62)
    print("REGRESSION METRICS (all data — see config.json for held-out CV)")
    print("=" * 62)
    m = regression_metrics(y, mu)
    for k, v in m.items():
        print(f"  {k.upper():<6} {v:+.4f}")
    print(f"  RPD verdict: {interpret_rpd(m['rpd'])}")

    print("\n" + "=" * 62)
    print(f"CONFORMAL COVERAGE (target >= {1 - cfg['alpha']:.2f})")
    print("=" * 62)
    cov = float(np.mean((y >= lo) & (y <= hi)))
    print(f"  marginal coverage : {cov:.3f}")
    print(f"  mean interval width: {float(np.mean(hi - lo)):.3f} °Bx")
    for v in np.unique(groups):
        s = groups == v
        c = float(np.mean((y[s] >= lo[s]) & (y[s] <= hi[s])))
        flag = "" if c >= 1 - cfg["alpha"] - 0.05 else "   <-- undercovered"
        print(f"  variety {str(v):<12} n={int(s.sum()):<4} coverage={c:.3f}{flag}")

    print("\n" + "=" * 62)
    print("BADGE BEHAVIOUR")
    print("=" * 62)
    badges = [badge_with_reason(a, b, ready_threshold=args.ready_threshold,
                                over_threshold=args.over_threshold)[0]
              for a, b in zip(lo, hi)]
    badges = np.array(badges)
    truth = np.where(y < args.ready_threshold, "RED",
                     np.where(y > args.over_threshold, "RED", "GREEN"))
    decided = badges != "YELLOW"
    abstain = float(np.mean(~decided))
    acc = float(np.mean(badges[decided] == truth[decided])) if decided.any() else float("nan")
    print(f"  abstention (YELLOW) rate : {abstain:.3f}")
    print(f"  accuracy when it commits : {acc:.3f}")
    fg = float(np.mean((badges == "GREEN") & (truth == "RED")))
    print(f"  false GREEN rate         : {fg:.4f}   (the costly error)")

    print("\n" + "=" * 62)
    print("EXPERT ROUTING")
    print("=" * 62)
    for v in np.unique(groups):
        s = groups == v
        share = w[s].mean(axis=0)
        print(f"  {str(v):<12} " + "  ".join(f"E{i}={p:.2f}" for i, p in enumerate(share)))
    print("\n  (If every variety routes to the same expert, the mixture has"
          "\n   collapsed — raise lambda_balance or lower the gate temperature.)")


if __name__ == "__main__":
    main()
