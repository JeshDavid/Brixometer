"""
Arrhenius inversion-kinetics model and TTI backcasting for Brixometer Mill Mode.

Physical basis
--------------
Post-harvest sucrose loss in sugarcane is dominated by two coupled processes:

1. **Acid/enzymatic inversion** — sucrose hydrolyses into glucose + fructose,
   catalysed by invertase and by the low pH of the expressed juice. This is
   effectively irreversible on transit timescales.
2. **Respiration** — residual living tissue consumes sugars.

Both are temperature-driven and are well approximated over the 15–45 °C transit
window by first-order kinetics with an Arrhenius rate constant:

    dS/dt = -k(T) * S
    k(T)  = A * exp(-Ea / (R * T))

Integrating over a measured thermal history T(t) gives the *thermal dose*:

    D = ∫ k(T(t)) dt

and therefore

    S_arrival = S_harvest * exp(-D)
    S_harvest = S_arrival * exp(+D)        <-- the backcast

`D` is exactly what a Time-Temperature Indicator (TTI) strip integrates
physically. A TTI whose own activation energy is matched to sucrose inversion
reads out a colour proportional to the same integral, so a single colour
measurement substitutes for a full logger trace.

Units
-----
Temperature in Kelvin internally, Celsius at the API boundary.
Brix in degrees Brix (°Bx). Time in hours.

References for parameter ranges are collected in docs/SCIENCE.md. The defaults
below are lab-fitted placeholders — **recalibrate against your own dataset**
before using these numbers in a payment decision.
"""

from __future__ import annotations

from dataclasses import dataclass, asdict
from typing import Sequence

import numpy as np

R_GAS = 8.314462618  # J mol^-1 K^-1

# numpy 2.0 renamed trapz -> trapezoid; support both so the repo runs on either.
_trapz = getattr(np, "trapezoid", None) or np.trapz


# --------------------------------------------------------------------------- #
# Kinetic parameters
# --------------------------------------------------------------------------- #
@dataclass(frozen=True)
class KineticParams:
    """First-order Arrhenius parameters for post-harvest sucrose loss.

    Attributes
    ----------
    ln_A : float
        Natural log of the pre-exponential factor (h^-1). Stored as a log to
        keep the fit numerically well-conditioned.
    Ea : float
        Activation energy in J/mol. Literature range for sucrose inversion in
        cane is roughly 60–95 kJ/mol depending on variety, pH and damage state.
    """

    ln_A: float = 24.6      # -> A ~ 4.8e10 h^-1
    Ea: float = 72_000.0    # J/mol

    def k(self, T_celsius: np.ndarray | float) -> np.ndarray:
        """Rate constant k(T) in h^-1 for temperature(s) given in Celsius."""
        T = np.asarray(T_celsius, dtype=float) + 273.15
        if np.any(T <= 0):
            raise ValueError("Temperature below absolute zero.")
        return np.exp(self.ln_A - self.Ea / (R_GAS * T))

    def as_dict(self) -> dict:
        return asdict(self)


DEFAULT_PARAMS = KineticParams()


# --------------------------------------------------------------------------- #
# Thermal dose
# --------------------------------------------------------------------------- #
def thermal_dose_from_trace(
    hours: Sequence[float],
    temps_c: Sequence[float],
    params: KineticParams = DEFAULT_PARAMS,
) -> float:
    """Integrate k(T(t)) dt over a logged thermal history (trapezoid rule).

    Parameters
    ----------
    hours : increasing timestamps in hours since harvest.
    temps_c : temperature in Celsius at each timestamp.

    Returns
    -------
    Dimensionless thermal dose D.
    """
    t = np.asarray(hours, dtype=float)
    T = np.asarray(temps_c, dtype=float)
    if t.ndim != 1 or t.shape != T.shape:
        raise ValueError("hours and temps_c must be 1-D arrays of equal length.")
    if t.size < 2:
        raise ValueError("Need at least two samples to integrate.")
    if np.any(np.diff(t) <= 0):
        raise ValueError("hours must be strictly increasing.")
    return float(_trapz(params.k(T), t))


def thermal_dose_isothermal(
    hours: float,
    temp_c: float,
    params: KineticParams = DEFAULT_PARAMS,
) -> float:
    """Thermal dose for a constant-temperature transit — the fallback when no
    TTI strip and no logger are available (uses the mill's ambient record)."""
    if hours < 0:
        raise ValueError("hours must be non-negative.")
    return float(params.k(temp_c) * hours)


def effective_temperature(dose: float, hours: float,
                          params: KineticParams = DEFAULT_PARAMS) -> float:
    """Invert a dose back to the single isothermal temperature (°C) that would
    have produced it. Useful for explaining a grade to a farmer in plain terms:
    'your lot travelled as if it sat at 38 °C for 9 hours'."""
    if hours <= 0 or dose <= 0:
        raise ValueError("hours and dose must be positive.")
    k_eff = dose / hours
    T = params.Ea / (R_GAS * (params.ln_A - np.log(k_eff)))
    return float(T - 273.15)


# --------------------------------------------------------------------------- #
# TTI strip readout
# --------------------------------------------------------------------------- #
@dataclass(frozen=True)
class TTICalibration:
    """Maps a TTI strip's normalised colour response to thermal dose.

    The strip is imaged by the same cross-polar RGB module used in Field Mode.
    `response` is a 0..1 extent-of-reaction value computed from the strip's
    colour relative to its printed unreacted and fully-reacted reference patches
    (see firmware/src/tti_decode.cpp).

    We model the strip itself as first-order with its own dose D_tti:

        response = 1 - exp(-D_tti)
        D_tti    = -ln(1 - response)

    and relate the strip's dose to the cane's dose by a single dimensionless
    coupling factor fitted on paired logger/strip experiments. The coupling is
    near-constant only when the strip's Ea is matched to the cane's; the
    `ea_mismatch_penalty` term widens the reported uncertainty when it is not.
    """

    coupling: float = 1.0
    strip_Ea: float = 72_000.0
    response_floor: float = 0.02
    response_ceiling: float = 0.98

    def dose(self, response: float) -> float:
        """Thermal dose implied by a strip response in [0, 1]."""
        if not 0.0 <= response <= 1.0:
            raise ValueError("TTI response must lie in [0, 1].")
        r = float(np.clip(response, self.response_floor, self.response_ceiling))
        return self.coupling * float(-np.log(1.0 - r))

    def saturated(self, response: float) -> bool:
        """True when the strip is past its reliable reading range — the grade
        must then fall back to the logger/ambient path, not silently guess."""
        return response >= self.response_ceiling or response <= self.response_floor


DEFAULT_TTI = TTICalibration()


# --------------------------------------------------------------------------- #
# Backcasting
# --------------------------------------------------------------------------- #
@dataclass(frozen=True)
class BackcastResult:
    brix_arrival: float
    brix_harvest: float
    dose: float
    loss_bx: float
    loss_pct: float
    effective_temp_c: float | None
    interval: tuple[float, float]
    method: str
    saturated: bool

    def summary(self) -> str:
        lo, hi = self.interval
        return (
            f"Arrival {self.brix_arrival:.2f} °Bx -> harvest "
            f"{self.brix_harvest:.2f} °Bx [{lo:.2f}, {hi:.2f}] "
            f"(+{self.loss_bx:.2f} °Bx, {self.loss_pct:.1f}% recovered, "
            f"method={self.method})"
        )


def backcast_brix(
    brix_arrival: float,
    dose: float,
    *,
    dose_rel_sigma: float = 0.15,
    z: float = 1.645,
    method: str = "tti",
    saturated: bool = False,
    hours: float | None = None,
    params: KineticParams = DEFAULT_PARAMS,
) -> BackcastResult:
    """Reconstruct harvest-time Brix from arrival Brix and a thermal dose.

    The uncertainty interval propagates a relative uncertainty on the dose
    (default 15%, which is what a well-calibrated strip achieves in lab
    conditions) through the exponential. Because the correction is
    multiplicative, the interval is asymmetric — that asymmetry is deliberate
    and should be shown to both parties rather than hidden behind a point
    estimate.

    A dose of 0 returns the arrival value unchanged, which is the correct
    behaviour for a lot weighed at the field edge.
    """
    if brix_arrival <= 0:
        raise ValueError("brix_arrival must be positive.")
    if dose < 0:
        raise ValueError("dose must be non-negative.")

    brix_harvest = brix_arrival * float(np.exp(dose))
    d_lo = max(0.0, dose * (1.0 - z * dose_rel_sigma))
    d_hi = dose * (1.0 + z * dose_rel_sigma)
    interval = (
        brix_arrival * float(np.exp(d_lo)),
        brix_arrival * float(np.exp(d_hi)),
    )

    eff_t = None
    if hours is not None and hours > 0 and dose > 0:
        eff_t = effective_temperature(dose, hours, params)

    loss_bx = brix_harvest - brix_arrival
    return BackcastResult(
        brix_arrival=float(brix_arrival),
        brix_harvest=float(brix_harvest),
        dose=float(dose),
        loss_bx=float(loss_bx),
        loss_pct=float(100.0 * loss_bx / brix_harvest) if brix_harvest else 0.0,
        effective_temp_c=eff_t,
        interval=interval,
        method=method,
        saturated=saturated,
    )


class BackcastStatus:
    """Mirrors firmware/src/tti_decode.h's BackcastStatus enum. Kept as string
    constants rather than a real Enum so JSON round-trips (backend <-> device)
    don't need a codec."""

    OK = "ok"
    INTEGRITY_MISMATCH = "integrity_mismatch"
    EXPOSURE_EXCEEDED = "exposure_exceeded"
    TTI_UNREADABLE = "tti_unreadable"


@dataclass(frozen=True)
class GatedBackcastResult:
    status: str
    brix_arrival: float
    brix_harvest: float | None       # None unless status == OK
    dose: float | None
    interval: tuple[float, float] | None
    implied_hours: float | None
    declared_hours: float
    deviation_hours: float | None

    def summary(self) -> str:
        if self.status != BackcastStatus.OK:
            return (
                f"NOT corrected ({self.status}): arrival {self.brix_arrival:.2f} °Bx, "
                f"declared {self.declared_hours:.1f} h transit -> manual QA required"
            )
        lo, hi = self.interval
        return (
            f"Corrected: arrival {self.brix_arrival:.2f} -> harvest "
            f"{self.brix_harvest:.2f} °Bx [{lo:.2f}, {hi:.2f}], "
            f"QR/TTI agree within {self.deviation_hours:.2f} h"
        )


def gated_backcast_from_tti(
    brix_arrival: float,
    tti_response: float,
    declared_hours: float,
    *,
    max_deviation_hours: float = 3.0,
    max_declared_hours: float = 48.0,
    reference_temp_c: float = 33.0,
    cal: TTICalibration = DEFAULT_TTI,
    params: KineticParams = DEFAULT_PARAMS,
) -> GatedBackcastResult:
    """Host-side mirror of firmware/src/tti_decode.cpp::backcast().

    Implements claims 11-13 of the filed specification: a mill-side correction
    is applied only when the QR-declared transit time and the TTI-implied
    transit time (computed against a fixed reference temperature, purely as a
    cross-check) agree within `max_deviation_hours`, AND the declared exposure
    does not exceed `max_declared_hours`. Any failure returns a result with
    `brix_harvest is None` — there is intentionally no fallback estimate here,
    because an unverified correction is a payment decision, not a convenience
    feature. Compare this to `backcast_from_tti` above, which is the
    unconditional arithmetic used only once this gate has already passed.
    """
    if brix_arrival <= 0:
        raise ValueError("brix_arrival must be positive.")
    if not 0.0 <= tti_response <= 1.0:
        raise ValueError("tti_response must lie in [0, 1].")
    if declared_hours < 0:
        raise ValueError("declared_hours must be non-negative.")

    if cal.saturated(tti_response):
        return GatedBackcastResult(
            status=BackcastStatus.TTI_UNREADABLE, brix_arrival=brix_arrival,
            brix_harvest=None, dose=None, interval=None,
            implied_hours=None, declared_hours=declared_hours, deviation_hours=None,
        )

    dose = cal.dose(tti_response)
    k_ref = params.k(reference_temp_c)
    implied_hours = float(dose / k_ref)
    deviation = abs(implied_hours - declared_hours)

    if deviation > max_deviation_hours:
        return GatedBackcastResult(
            status=BackcastStatus.INTEGRITY_MISMATCH, brix_arrival=brix_arrival,
            brix_harvest=None, dose=dose, interval=None,
            implied_hours=implied_hours, declared_hours=declared_hours,
            deviation_hours=deviation,
        )
    if declared_hours > max_declared_hours:
        return GatedBackcastResult(
            status=BackcastStatus.EXPOSURE_EXCEEDED, brix_arrival=brix_arrival,
            brix_harvest=None, dose=dose, interval=None,
            implied_hours=implied_hours, declared_hours=declared_hours,
            deviation_hours=deviation,
        )

    # Integrity check passed: correct using the TTI's own measured dose, not
    # the reference-temperature estimate used above only for cross-validation.
    r = backcast_brix(brix_arrival, dose, method="tti", saturated=False)
    return GatedBackcastResult(
        status=BackcastStatus.OK, brix_arrival=brix_arrival,
        brix_harvest=r.brix_harvest, dose=dose, interval=r.interval,
        implied_hours=implied_hours, declared_hours=declared_hours,
        deviation_hours=deviation,
    )


def backcast_from_tti(
    brix_arrival: float,
    tti_response: float,
    *,
    hours: float | None = None,
    cal: TTICalibration = DEFAULT_TTI,
    params: KineticParams = DEFAULT_PARAMS,
) -> BackcastResult:
    """Convenience path: strip colour in, corrected grade out."""
    dose = cal.dose(tti_response)
    return backcast_brix(
        brix_arrival,
        dose,
        method="tti",
        saturated=cal.saturated(tti_response),
        hours=hours,
        params=params,
    )


def backcast_from_logger(
    brix_arrival: float,
    hours: Sequence[float],
    temps_c: Sequence[float],
    params: KineticParams = DEFAULT_PARAMS,
) -> BackcastResult:
    """Reference path used to *calibrate* the TTI coupling factor."""
    dose = thermal_dose_from_trace(hours, temps_c, params)
    return backcast_brix(
        brix_arrival,
        dose,
        dose_rel_sigma=0.05,      # logger traces are far tighter than strips
        method="logger",
        hours=float(hours[-1] - hours[0]),
        params=params,
    )


# --------------------------------------------------------------------------- #
# Parameter fitting
# --------------------------------------------------------------------------- #
def fit_kinetics(
    brix_harvest: Sequence[float],
    brix_arrival: Sequence[float],
    hours: Sequence[float],
    temps_c: Sequence[float],
) -> KineticParams:
    """Fit (ln_A, Ea) from paired isothermal hold experiments.

    Linearising  ln(S0/S1) = A * exp(-Ea/RT) * t  gives

        ln( ln(S0/S1) / t ) = ln_A - (Ea/R) * (1/T)

    which is an ordinary least-squares line in 1/T. Run holds at at least
    four temperatures spanning 20–45 °C, three durations each, for a usable fit.
    """
    S0 = np.asarray(brix_harvest, float)
    S1 = np.asarray(brix_arrival, float)
    t = np.asarray(hours, float)
    T = np.asarray(temps_c, float) + 273.15

    if not (S0.shape == S1.shape == t.shape == T.shape):
        raise ValueError("All inputs must have the same shape.")
    if np.any(t <= 0) or np.any(S0 <= 0) or np.any(S1 <= 0):
        raise ValueError("Times and Brix values must be positive.")
    if np.any(S1 >= S0):
        raise ValueError("Arrival Brix must be below harvest Brix for a fit.")

    y = np.log(np.log(S0 / S1) / t)
    x = 1.0 / T
    slope, intercept = np.polyfit(x, y, 1)
    return KineticParams(ln_A=float(intercept), Ea=float(-slope * R_GAS))


if __name__ == "__main__":  # pragma: no cover
    res = backcast_from_tti(brix_arrival=17.4, tti_response=0.21, hours=14.0)
    print(res.summary())
    print(f"effective transit temperature: {res.effective_temp_c:.1f} °C")
