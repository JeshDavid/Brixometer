"""
Conformal Mixture-of-Experts (CMoE) regressor for field-mode Brix prediction.

Why a mixture of experts here
-----------------------------
Sugarcane varieties differ enough in rind optics and fibre content that a single
global calibration underfits: a model tuned for Co 86032 systematically biases
on Co 0238. The classic fix is one model per variety, but that needs a variety
label at inference time and generalises badly to a fifth variety.

A gated mixture learns soft variety/maturity regimes from the spectrum itself.
The gate is trained jointly, so at inference the device needs no variety input —
it just needs the spectrum. Expert specialisation is encouraged by an entropy
penalty on the gate, keeping routing from collapsing onto one expert.

The "C" — conformal calibration — is applied *after* training in conformal.py.
That separation is deliberate: the interval guarantee is distribution-free and
must not be entangled with the fitting procedure.
"""

from __future__ import annotations

import torch
import torch.nn as nn
import torch.nn.functional as F


class Expert(nn.Module):
    """One small MLP head. Kept tiny — this runs int8 on an ESP32-S3."""

    def __init__(self, in_dim: int, hidden: int = 32, p_drop: float = 0.1) -> None:
        super().__init__()
        self.net = nn.Sequential(
            nn.Linear(in_dim, hidden),
            nn.SiLU(),
            nn.Dropout(p_drop),
            nn.Linear(hidden, hidden // 2),
            nn.SiLU(),
            nn.Linear(hidden // 2, 1),
        )

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        return self.net(x).squeeze(-1)


class Gate(nn.Module):
    """Softmax router over experts, with temperature for sharpening."""

    def __init__(self, in_dim: int, n_experts: int, hidden: int = 24,
                 temperature: float = 1.0) -> None:
        super().__init__()
        self.temperature = temperature
        self.net = nn.Sequential(
            nn.Linear(in_dim, hidden),
            nn.SiLU(),
            nn.Linear(hidden, n_experts),
        )

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        return F.softmax(self.net(x) / self.temperature, dim=-1)


class MixtureOfExperts(nn.Module):
    """Gated mixture producing a point estimate and a heteroscedastic scale.

    The scale head is not the uncertainty guarantee — conformal calibration
    provides that. The scale is used as a *normaliser* so conformal intervals
    can adapt to input difficulty instead of being one fixed width.
    """

    def __init__(self, in_dim: int, n_experts: int = 4, hidden: int = 32,
                 temperature: float = 1.0) -> None:
        super().__init__()
        self.n_experts = n_experts
        self.experts = nn.ModuleList(
            Expert(in_dim, hidden) for _ in range(n_experts)
        )
        self.gate = Gate(in_dim, n_experts, temperature=temperature)
        self.scale_head = nn.Sequential(
            nn.Linear(in_dim, 16), nn.SiLU(), nn.Linear(16, 1), nn.Softplus(),
        )

    def forward(self, x: torch.Tensor):
        w = self.gate(x)                                    # (B, E)
        preds = torch.stack([e(x) for e in self.experts], -1)  # (B, E)
        mu = (w * preds).sum(-1)                            # (B,)
        sigma = self.scale_head(x).squeeze(-1) + 1e-3       # (B,)
        return mu, sigma, w, preds


def cmoe_loss(
    mu: torch.Tensor,
    sigma: torch.Tensor,
    w: torch.Tensor,
    preds: torch.Tensor,
    y: torch.Tensor,
    *,
    lambda_nll: float = 0.3,
    lambda_entropy: float = 0.01,
    lambda_balance: float = 0.05,
    huber_delta: float = 1.0,
) -> tuple[torch.Tensor, dict]:
    """Composite objective.

    huber      — robust point loss; Brix references have occasional bad readings
    nll        — trains the scale head to track actual error magnitude
    entropy    — per-sample gate entropy penalty; encourages confident routing
    balance    — batch-level load balancing; stops experts from dying
    """
    huber = F.huber_loss(mu, y, delta=huber_delta)

    nll = (torch.log(sigma) + 0.5 * ((y - mu) / sigma) ** 2).mean()

    ent = -(w * torch.log(w + 1e-9)).sum(-1).mean()

    load = w.mean(0)                                  # (E,)
    target = torch.full_like(load, 1.0 / w.shape[-1])
    balance = ((load - target) ** 2).sum()

    total = huber + lambda_nll * nll + lambda_entropy * ent + lambda_balance * balance
    return total, {
        "huber": float(huber.detach()),
        "nll": float(nll.detach()),
        "gate_entropy": float(ent.detach()),
        "balance": float(balance.detach()),
        "total": float(total.detach()),
    }


@torch.no_grad()
def predict(model: MixtureOfExperts, X: torch.Tensor):
    """Inference helper: returns (mu, sigma, gate_weights) as numpy arrays."""
    model.eval()
    mu, sigma, w, _ = model(X)
    return mu.cpu().numpy(), sigma.cpu().numpy(), w.cpu().numpy()
