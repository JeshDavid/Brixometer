"""
Spectral preprocessing for 18-channel NIR + cross-polar RGB fusion.

The AS7263/AS7265x-class front end gives sparse, broad-band channels rather than
a continuous spectrum, so classical chemometrics still applies but with care:
derivative filters need short windows, and channel-to-channel gain drift matters
more than it would on a benchtop instrument.

Pipeline order (this order is not arbitrary):
    raw counts -> dark/white referencing -> log(1/R) -> SNV -> Savitzky-Golay
    -> optional baseline removal -> feature vector (+ RGB texture features)
"""

from __future__ import annotations

import numpy as np
from scipy.signal import savgol_filter

# Nominal AS7265x channel centres (nm). Adjust to your actual front end.
CHANNEL_NM = np.array([
    410, 435, 460, 485, 510, 535, 560, 585, 610,
    645, 680, 705, 730, 760, 810, 860, 900, 940,
], dtype=float)
N_CHANNELS = len(CHANNEL_NM)


def reference_correct(raw: np.ndarray, dark: np.ndarray, white: np.ndarray) -> np.ndarray:
    """Convert raw counts to reflectance in [0,1] using dark and white refs.

    R = (raw - dark) / (white - dark), clipped to avoid log blow-ups.
    """
    raw, dark, white = map(lambda a: np.asarray(a, float), (raw, dark, white))
    denom = white - dark
    if np.any(denom <= 0):
        raise ValueError("White reference must exceed dark reference on every channel.")
    R = (raw - dark) / denom
    return np.clip(R, 1e-4, 1.5)


def absorbance(reflectance: np.ndarray) -> np.ndarray:
    """log(1/R) — linearises concentration response (pseudo-Beer-Lambert)."""
    return np.log10(1.0 / np.clip(np.asarray(reflectance, float), 1e-4, None))


def snv(X: np.ndarray) -> np.ndarray:
    """Standard Normal Variate: removes multiplicative scatter caused by
    stem curvature, surface wax and probe standoff variation."""
    X = np.atleast_2d(np.asarray(X, float))
    mu = X.mean(axis=1, keepdims=True)
    sd = X.std(axis=1, keepdims=True)
    sd = np.where(sd < 1e-8, 1.0, sd)
    return (X - mu) / sd


def msc(X: np.ndarray, reference: np.ndarray | None = None) -> tuple[np.ndarray, np.ndarray]:
    """Multiplicative Scatter Correction. Returns (corrected, reference)."""
    X = np.atleast_2d(np.asarray(X, float))
    ref = X.mean(axis=0) if reference is None else np.asarray(reference, float)
    out = np.empty_like(X)
    for i, row in enumerate(X):
        slope, intercept = np.polyfit(ref, row, 1)
        out[i] = (row - intercept) / (slope if abs(slope) > 1e-8 else 1.0)
    return out, ref


def sg_derivative(X: np.ndarray, order: int = 1, window: int = 5, poly: int = 2) -> np.ndarray:
    """Savitzky-Golay derivative. With only 18 channels keep window <= 7."""
    if window % 2 == 0:
        raise ValueError("Savitzky-Golay window must be odd.")
    if window > N_CHANNELS:
        raise ValueError("Window wider than the channel count.")
    X = np.atleast_2d(np.asarray(X, float))
    return savgol_filter(X, window_length=window, polyorder=poly, deriv=order, axis=1)


def rgb_texture_features(patch: np.ndarray) -> np.ndarray:
    """Six cheap features from a cross-polarised RGB internode patch.

    Cross-polarisation suppresses specular glare from the wax layer, so the
    remaining signal is genuinely subsurface. Rind colour and mottling correlate
    with maturity and with borer/red-rot stress, which the NIR channels alone
    confound with sugar.

    Returns: [mean_R, mean_G, mean_B, std_G, green_red_ratio, edge_density]
    """
    patch = np.asarray(patch, float)
    if patch.ndim != 3 or patch.shape[2] != 3:
        raise ValueError("patch must be HxWx3.")
    p = patch / 255.0 if patch.max() > 1.5 else patch
    mr, mg, mb = p[..., 0].mean(), p[..., 1].mean(), p[..., 2].mean()
    sg = p[..., 1].std()
    gr = mg / mr if mr > 1e-6 else 0.0
    gray = p.mean(axis=2)
    gx = np.abs(np.diff(gray, axis=1)).mean()
    gy = np.abs(np.diff(gray, axis=0)).mean()
    return np.array([mr, mg, mb, sg, gr, 0.5 * (gx + gy)], dtype=float)


def build_features(
    reflectance: np.ndarray,
    rgb_feats: np.ndarray | None = None,
    *,
    use_derivative: bool = True,
) -> np.ndarray:
    """Full field-mode feature builder: (n, 18) reflectance -> (n, d) features."""
    A = absorbance(np.atleast_2d(reflectance))
    A = snv(A)
    blocks = [A]
    if use_derivative:
        blocks.append(sg_derivative(A, order=1, window=5, poly=2))
    X = np.hstack(blocks)
    if rgb_feats is not None:
        rgb = np.atleast_2d(np.asarray(rgb_feats, float))
        if rgb.shape[0] != X.shape[0]:
            raise ValueError("RGB feature rows must match spectral rows.")
        X = np.hstack([X, rgb])
    return X


class StandardScaler:
    """Minimal scaler kept in-repo so the exact same constants can be baked
    into the firmware header without a scikit-learn dependency on device."""

    def __init__(self) -> None:
        self.mean_: np.ndarray | None = None
        self.scale_: np.ndarray | None = None

    def fit(self, X: np.ndarray) -> "StandardScaler":
        X = np.atleast_2d(np.asarray(X, float))
        self.mean_ = X.mean(axis=0)
        sd = X.std(axis=0)
        self.scale_ = np.where(sd < 1e-8, 1.0, sd)
        return self

    def transform(self, X: np.ndarray) -> np.ndarray:
        if self.mean_ is None:
            raise RuntimeError("Scaler not fitted.")
        return (np.atleast_2d(np.asarray(X, float)) - self.mean_) / self.scale_

    def fit_transform(self, X: np.ndarray) -> np.ndarray:
        return self.fit(X).transform(X)
