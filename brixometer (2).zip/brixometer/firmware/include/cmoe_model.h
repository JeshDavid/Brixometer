// PLACEHOLDER — replaced by ml/export_tflite.py once you have a trained model.
// This stub exists so the firmware compiles in CI before any training run.
#pragma once
#include <cstdint>

#define BRIX_MODEL_IN_DIM    42
#define BRIX_MODEL_EXPERTS   4
#define BRIX_CONFORMAL_QHAT  1.960000f
#define BRIX_CONFORMAL_ALPHA 0.1000f

alignas(16) const unsigned char g_cmoe_model[] = {0x00};
const unsigned int g_cmoe_model_len = 1;

const float g_feature_mean[BRIX_MODEL_IN_DIM]  = {0};
const float g_feature_scale[BRIX_MODEL_IN_DIM] = {
  1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,
  1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1
};
