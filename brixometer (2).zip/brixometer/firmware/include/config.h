// CryoCivic / Brixometer firmware configuration and tunables.
// Mirrors the device architecture as filed: single measurement head (104),
// bayonet-mounted swappable adapters (110 field / 111 mill), force sensor (118),
// orientation sensor / IMU (119), embedded control unit (116).
#pragma once
#include <cstdint>

// ---------------------------------------------------------------- pins -----
constexpr int PIN_I2C_SDA        = 8;
constexpr int PIN_I2C_SCL        = 9;
constexpr int PIN_LAMP_EN        = 4;   // illumination LED ring (106)
constexpr int PIN_LAMP_PWM_CH    = 0;
constexpr int PIN_BTN_POWER      = 13;  // power button (113)
constexpr int PIN_BTN_SCAN       = 5;
constexpr int PIN_BTN_MODE       = 6;   // mode button (114): field <-> mill
constexpr int PIN_LED_GREEN      = 15;
constexpr int PIN_LED_YELLOW     = 16;
constexpr int PIN_LED_RED        = 17;  // status LED indicator (115)
constexpr int PIN_BATT_SENSE     = 1;   // ADC1_CH0 via 2:1 divider
constexpr int PIN_SD_CS          = 10;
constexpr int PIN_FORCE_SENSE    = 2;   // force sensor (118), ADC, resistive FSR
constexpr int PIN_VIBE_MOTOR     = 7;   // haptic cue, complements voice/icon output

// IMU (orientation sensor, 119) shares the I2C bus with the spectral sensor.
constexpr uint8_t IMU_I2C_ADDR   = 0x68;

// --------------------------------------------------------- measurement -----
constexpr uint8_t  N_SPECTRAL_CHANNELS = 18;
constexpr uint8_t  SCANS_PER_READING   = 8;    // averaged to cut detector noise
constexpr uint16_t LAMP_WARMUP_MS      = 250;  // stabilise before integrating
constexpr uint16_t INTEGRATION_MS      = 50;

constexpr float REFERENCE_TEMP_DRIFT_C = 5.0f;
constexpr uint32_t REFERENCE_MAX_AGE_MS = 30UL * 60UL * 1000UL;  // 30 min

// --------------------------------------------------- contact validation ----
// Per claim 4: a reading is only accepted within a declared pressure range.
// Values are placeholders for an FSR402-class sensor; calibrate per adapter,
// since the conical (110) and flat-faced (111) tips present different contact
// areas for the same applied force.
constexpr float FORCE_MIN_N          = 2.5f;
constexpr float FORCE_MAX_N          = 12.0f;
constexpr uint16_t FORCE_STABLE_MS   = 150;   // must hold range this long

// Per claim 5: orientation is validated during capture. Tilt tolerance is
// generous for field use (a farmer is not going to spirit-level a handheld
// device) but rules out captures where the head is not plausibly against
// a stem or cut face at all (e.g. pointed at the sky, dropped).
constexpr float MAX_TILT_DEG         = 60.0f;

// ------------------------------------------------------------- badges ------
constexpr float BRIX_READY_THRESHOLD = 18.0f;
constexpr float BRIX_OVER_THRESHOLD  = 21.0f;
constexpr float MAX_ACCEPTABLE_INTERVAL_BX = 3.0f;
constexpr float MIN_VALID_REFLECTANCE      = 0.02f;
constexpr float MAX_VALID_REFLECTANCE      = 0.98f;

// ----------------------------------------------------------- mill mode -----
constexpr float TTI_RESPONSE_FLOOR   = 0.02f;
constexpr float TTI_RESPONSE_CEILING = 0.98f;
constexpr float ARRHENIUS_LN_A       = 24.6f;
constexpr float ARRHENIUS_EA         = 72000.0f;   // J/mol - refit per docs/DATA_SPEC.md
constexpr float R_GAS                = 8.314462618f;
constexpr float TTI_COUPLING         = 1.0f;
constexpr float DOSE_REL_SIGMA       = 0.15f;

// Per claims 11-13: the QR-derived harvest timestamp and the TTI-derived
// exposure must cross-validate before any correction is applied at all.
// This is a hard gate, not a fallback — if it fails, backcasting is disabled
// and the lot is flagged for manual QA. There is deliberately no "best guess"
// path here, unlike a stale white reference in Field Mode: an unverified mill
// correction is a payment decision, and a refusal costs far less than a wrong
// one.
constexpr float TTI_QR_MAX_DEVIATION_HOURS = 3.0f;  // agreement tolerance
constexpr float TTI_MAX_DECLARED_HOURS     = 48.0f; // beyond this: manual QA
constexpr float TTI_ASSUMED_REF_TEMP_C     = 33.0f; // used only to sanity-check
                                                     // TTI-implied hours against
                                                     // the QR-declared hours

// ------------------------------------------------------------- power -------
constexpr uint32_t IDLE_SLEEP_MS   = 120000;  // deep sleep after 2 min idle
constexpr float    BATT_LOW_VOLTS  = 3.45f;
