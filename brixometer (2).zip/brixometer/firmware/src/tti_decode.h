#pragma once
#include <cstdint>

struct TtiReading {
  float response;        // extent of reaction, 0..1
  bool  saturated;
  bool  valid;
};

enum class BackcastStatus : uint8_t {
  OK,                 // integrity check passed, correction applied
  INTEGRITY_MISMATCH, // QR timestamp and TTI exposure disagree beyond tolerance
  EXPOSURE_EXCEEDED,  // declared/implied exposure beyond the bound the model is trusted for
  TTI_UNREADABLE,     // strip could not be read at all
};

struct BackcastResult {
  BackcastStatus status;
  float brixArrival;
  float brixHarvest;     // only meaningful when status == OK
  float dose;
  float lo, hi;           // only meaningful when status == OK
  bool  correctionApplied;
};

namespace tti {
bool read(TtiReading& out);
float doseFromResponse(float response);

// Per claims 11-13: cross-validates the QR-declared transit hours against the
// hours implied by the TTI's own thermal dose (via the assumed reference
// temperature). Correction is enabled ONLY when they agree within
// TTI_QR_MAX_DEVIATION_HOURS and declared hours are within
// TTI_MAX_DECLARED_HOURS. On any failure the result is flagged for manual QA
// and NO Brix figure is computed — there is deliberately no fallback estimate
// here, because an unverified correction is a payment decision.
BackcastResult backcast(float brixArrival, const TtiReading& t, float qrTransitHours);
}  // namespace tti
