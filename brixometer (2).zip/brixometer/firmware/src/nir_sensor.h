#pragma once
#include <cstdint>
#include "config.h"

struct SpectralReading {
  float raw[N_SPECTRAL_CHANNELS];          // averaged raw counts
  float reflectance[N_SPECTRAL_CHANNELS];  // dark/white referenced, 0..1
  float rgb[6];                            // cross-polar RGB texture features
  float sensorTempC;
  uint32_t timestampMs;
  bool valid;
};

namespace nir {
bool begin();
bool captureDarkReference();
bool captureWhiteReference();
bool referenceIsStale();
bool acquire(SpectralReading& out);
const char* lastErrorText();
}  // namespace nir
