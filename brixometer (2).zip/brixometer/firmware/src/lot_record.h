#pragma once
#include <Arduino.h>
#include "nir_sensor.h"
#include "cmoe_inference.h"
#include "tti_decode.h"

struct LotRecord {
  String lotId;
  String farmerId;
  String fpoId;
  String varietyHint;
  uint32_t harvestEpoch;
  float declaredTransitHours;
  float arrivalBrix;
  float harvestBrix;
  float thermalDose;
  BackcastStatus status;
  String signature;       // Ed25519 over the canonical record
};

namespace lot {
void begin();
bool readQr(LotRecord& out);
bool signAndStore(LotRecord& rec);   // stores regardless of status - a manual-QA
                                      // flag is itself part of the auditable record
bool appendFieldScan(const SpectralReading& r, const BrixPrediction& p, Badge b);
String canonicalJson(const LotRecord& rec);
}  // namespace lot
