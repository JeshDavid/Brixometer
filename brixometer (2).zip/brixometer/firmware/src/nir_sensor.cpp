/**
 * 18-channel NIR acquisition with dark/white referencing.
 *
 * The single largest source of field error on a low-cost spectral front end is
 * not the detector — it is illumination drift and probe standoff. Three
 * countermeasures live here:
 *
 *   1. Dark reference taken lamp-off immediately before every scan, so detector
 *      dark current and stray ambient light are subtracted per-reading.
 *   2. White reference against a PTFE tile in the cap, invalidated on a 30-min
 *      timer or a 5 °C internal temperature move.
 *   3. Saturation and under-range rejection per channel — a clipped channel is
 *      an error, not a data point.
 */

#include "nir_sensor.h"
#include <Arduino.h>
#include <Adafruit_AS7341.h>

namespace {
Adafruit_AS7341 g_sensor;
float g_dark[N_SPECTRAL_CHANNELS]  = {0};
float g_white[N_SPECTRAL_CHANNELS] = {0};
bool  g_haveWhite = false;
uint32_t g_whiteAtMs = 0;
float g_whiteAtTempC = 0.0f;
const char* g_err = "";

void lampOn()  { digitalWrite(PIN_LAMP_EN, HIGH); delay(LAMP_WARMUP_MS); }
void lampOff() { digitalWrite(PIN_LAMP_EN, LOW); delay(20); }

float readInternalTempC() {
  // Placeholder: replace with your on-board NTC / sensor die temperature.
  return 30.0f;
}

bool readAveraged(float* out, uint8_t scans) {
  double acc[N_SPECTRAL_CHANNELS] = {0};
  uint16_t buf[12];
  for (uint8_t s = 0; s < scans; ++s) {
    if (!g_sensor.readAllChannels(buf)) { g_err = "I2C read failed"; return false; }
    // AS7341 gives 10 usable channels + clear/NIR; the 18-channel build maps
    // two staggered integrations into one vector. Adjust to your front end.
    for (uint8_t c = 0; c < N_SPECTRAL_CHANNELS; ++c) {
      acc[c] += buf[c % 12];
    }
    delay(INTEGRATION_MS);
  }
  for (uint8_t c = 0; c < N_SPECTRAL_CHANNELS; ++c) out[c] = (float)(acc[c] / scans);
  return true;
}
}  // namespace

namespace nir {

bool begin() {
  if (!g_sensor.begin()) { g_err = "AS7341 not detected"; return false; }
  g_sensor.setATIME(100);
  g_sensor.setASTEP(999);
  g_sensor.setGain(AS7341_GAIN_64X);
  return true;
}

bool captureDarkReference() {
  lampOff();
  return readAveraged(g_dark, SCANS_PER_READING);
}

bool captureWhiteReference() {
  if (!captureDarkReference()) return false;
  lampOn();
  bool ok = readAveraged(g_white, SCANS_PER_READING);
  lampOff();
  if (!ok) return false;

  for (uint8_t c = 0; c < N_SPECTRAL_CHANNELS; ++c) {
    if (g_white[c] - g_dark[c] <= 1.0f) {
      g_err = "White reference too dark - check lamp/tile";
      return false;
    }
  }
  g_haveWhite = true;
  g_whiteAtMs = millis();
  g_whiteAtTempC = readInternalTempC();
  return true;
}

bool referenceIsStale() {
  if (!g_haveWhite) return true;
  if (millis() - g_whiteAtMs > REFERENCE_MAX_AGE_MS) return true;
  return fabsf(readInternalTempC() - g_whiteAtTempC) > REFERENCE_TEMP_DRIFT_C;
}

bool acquire(SpectralReading& out) {
  out.valid = false;
  g_err = "";

  if (referenceIsStale()) {
    g_err = "White reference stale - cap the device and re-reference";
    return false;
  }
  if (!captureDarkReference()) return false;

  lampOn();
  bool ok = readAveraged(out.raw, SCANS_PER_READING);
  lampOff();
  if (!ok) return false;

  for (uint8_t c = 0; c < N_SPECTRAL_CHANNELS; ++c) {
    float denom = g_white[c] - g_dark[c];
    float R = (out.raw[c] - g_dark[c]) / denom;
    if (R > MAX_VALID_REFLECTANCE) { g_err = "Detector saturated - move off the tile"; return false; }
    if (R < MIN_VALID_REFLECTANCE) { g_err = "Signal too low - check probe contact"; return false; }
    out.reflectance[c] = R;
  }

  // RGB texture features come from the cross-polar camera module; see
  // rgb_capture.cpp. Zeroed here when the module is absent so the model can
  // still run spectral-only (accuracy degrades — evaluate both configurations).
  for (uint8_t i = 0; i < 6; ++i) out.rgb[i] = 0.0f;

  out.sensorTempC = readInternalTempC();
  out.timestampMs = millis();
  out.valid = true;
  return true;
}

const char* lastErrorText() { return g_err[0] ? g_err : "Unknown sensor error"; }

}  // namespace nir
