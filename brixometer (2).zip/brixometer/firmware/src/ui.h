#pragma once
#include "cmoe_inference.h"
#include "lot_record.h"
#include "tti_decode.h"

namespace ui {
void begin();
void status(const char* msg);
void warn(const char* msg);
void error(const char* msg);
void fatal(const char* msg);
void showFieldResult(const BrixPrediction& p, Badge b);
void showMillResult(const LotRecord& lot, const BackcastResult& bc);
}  // namespace ui
