/**
 * OLED + LED + haptic user interface.
 *
 * Per the spec's accessibility intent (bilingual, icon-led, voice-assisted
 * output for users of varying literacy), the colour badge and a short icon are
 * the primary channel; numeric detail on the OLED is secondary, for the FPO
 * technician. Voice/regional-language output is a hook (voice::speak) left
 * for a language pack — not implemented here, since it's a content and
 * localisation exercise, not a firmware one.
 */

#include "ui.h"
#include "config.h"
#include <Adafruit_SSD1306.h>

namespace {
Adafruit_SSD1306 g_display(128, 64, &Wire, -1);
bool g_ok = false;

void line(int y, int size, const char* text) {
  g_display.setTextSize(size);
  g_display.setCursor(0, y);
  g_display.println(text);
}
}  // namespace

namespace ui {

void begin() {
  g_ok = g_display.begin(SSD1306_SWITCHCAPVCC, 0x3C);
  if (!g_ok) { Serial.println("OLED not found - serial UI only"); return; }
  g_display.clearDisplay();
  g_display.setTextColor(SSD1306_WHITE);
  line(0, 2, "Brixometer");
  line(24, 1, BRIX_FW_VERSION);
  g_display.display();
  delay(800);
}

void status(const char* msg) {
  Serial.printf("[status] %s\n", msg);
  if (!g_ok) return;
  g_display.clearDisplay();
  line(0, 1, msg);
  g_display.display();
}

void warn(const char* msg)  { Serial.printf("[warn] %s\n", msg);  status(msg); }
void error(const char* msg) { Serial.printf("[error] %s\n", msg); status(msg); }

void fatal(const char* msg) {
  Serial.printf("[FATAL] %s\n", msg);
  status(msg);
  while (true) {
    digitalWrite(PIN_LED_RED, HIGH); delay(200);
    digitalWrite(PIN_LED_RED, LOW);  delay(200);
  }
}

void showFieldResult(const BrixPrediction& p, Badge b) {
  Serial.printf("[field] %.2f Bx [%.2f, %.2f] -> %s\n",
                p.mu, p.lo, p.hi, cmoe::badgeText(b));
  if (!g_ok) return;
  char buf[32];
  g_display.clearDisplay();
  line(0, 2, cmoe::badgeText(b));
  snprintf(buf, sizeof(buf), "%.1f Bx", p.mu);
  line(22, 2, buf);
  snprintf(buf, sizeof(buf), "range %.1f-%.1f", p.lo, p.hi);
  line(46, 1, buf);
  line(56, 1, cmoe::badgeReason(b, p.lo, p.hi));
  g_display.display();
}

void showMillResult(const LotRecord& lot, const BackcastResult& bc) {
  const char* statusStr =
      bc.status == BackcastStatus::OK ? "CORRECTED" :
      bc.status == BackcastStatus::INTEGRITY_MISMATCH ? "MISMATCH - MANUAL QA" :
      bc.status == BackcastStatus::EXPOSURE_EXCEEDED ? "EXPIRED - MANUAL QA" :
      "UNREADABLE - MANUAL QA";

  Serial.printf("[mill] %s arrival=%.2f status=%s\n",
                lot.lotId.c_str(), bc.brixArrival, statusStr);
  if (!g_ok) return;
  char buf[40];
  g_display.clearDisplay();
  line(0, 1, lot.lotId.c_str());
  snprintf(buf, sizeof(buf), "arrive %.1f Bx", bc.brixArrival);
  line(12, 1, buf);

  if (bc.status == BackcastStatus::OK) {
    snprintf(buf, sizeof(buf), "HARVEST %.1f Bx", bc.brixHarvest);
    line(24, 1, buf);
    snprintf(buf, sizeof(buf), "range %.1f-%.1f", bc.lo, bc.hi);
    line(36, 1, buf);
  } else {
    line(24, 1, statusStr);
    line(36, 1, "No correction applied");
  }
  line(48, 1, lot.signature.c_str());
  g_display.display();
}

}  // namespace ui
