#include "contact_gate.h"
#include "config.h"
#include <Arduino.h>
#include <Wire.h>
#include <cmath>

namespace {
uint32_t g_inRangeSinceMs = 0;
float g_lastForceN = 0.0f;
float g_lastTiltDeg = 0.0f;

// FSR402-class sensor: voltage divider against a fixed resistor. The
// force-to-voltage curve is nonlinear and part-specific; this is a
// placeholder linearisation to be replaced with a per-unit calibration
// table during production test.
float readForceNewtons() {
  const int raw = analogRead(PIN_FORCE_SENSE);       // 0..4095 on ESP32-S3 ADC
  const float v = (raw / 4095.0f) * 3.3f;
  if (v < 0.05f) return 0.0f;                        // no contact
  return powf(v / 3.3f, 1.6f) * 20.0f;                // fitted placeholder curve
}

// Reads accelerometer tilt from the IMU at 119. Returns degrees off the
// device's designed measurement axis. Placeholder until the IMU driver
// (e.g. an MPU6050/BMI160-class part) is wired in.
float readTiltDegrees() {
  Wire.beginTransmission(IMU_I2C_ADDR);
  Wire.write(0x3B);  // ACCEL_XOUT_H on MPU6050-compatible register map
  if (Wire.endTransmission(false) != 0) return 0.0f;  // IMU absent: don't block on it
  Wire.requestFrom((uint8_t)IMU_I2C_ADDR, (uint8_t)6);
  if (Wire.available() < 6) return 0.0f;

  int16_t ax = (Wire.read() << 8) | Wire.read();
  int16_t ay = (Wire.read() << 8) | Wire.read();
  int16_t az = (Wire.read() << 8) | Wire.read();

  const float axf = ax, ayf = ay, azf = az;
  const float mag = sqrtf(axf * axf + ayf * ayf + azf * azf);
  if (mag < 1.0f) return 0.0f;

  // Angle between the measured gravity vector and the device's own +Z axis
  // (the axis the measurement head points along).
  const float cosTheta = fabsf(azf) / mag;
  return acosf(fminf(fmaxf(cosTheta, -1.0f), 1.0f)) * 180.0f / (float)M_PI;
}
}  // namespace

namespace contact_gate {

bool begin() {
  analogReadResolution(12);
  return true;
}

ContactState poll() {
  g_lastForceN = readForceNewtons();
  g_lastTiltDeg = readTiltDegrees();

  if (g_lastForceN < FORCE_MIN_N) { g_inRangeSinceMs = 0; return ContactState::FORCE_LOW; }
  if (g_lastForceN > FORCE_MAX_N) { g_inRangeSinceMs = 0; return ContactState::FORCE_HIGH; }
  if (g_lastTiltDeg > MAX_TILT_DEG) { g_inRangeSinceMs = 0; return ContactState::TILTED; }

  if (g_inRangeSinceMs == 0) g_inRangeSinceMs = millis();
  if (millis() - g_inRangeSinceMs < FORCE_STABLE_MS) return ContactState::NOT_READY;
  return ContactState::READY;
}

const char* stateText(ContactState s) {
  switch (s) {
    case ContactState::FORCE_LOW:  return "Press firmly against the stem";
    case ContactState::FORCE_HIGH: return "Ease off - pressing too hard";
    case ContactState::TILTED:     return "Hold the device level";
    case ContactState::NOT_READY:  return "Hold steady...";
    case ContactState::READY:      return "Ready";
    default:                       return "";
  }
}

float lastForceN()  { return g_lastForceN; }
float lastTiltDeg() { return g_lastTiltDeg; }

}  // namespace contact_gate
