/**
 * TTI strip decoding and mill-side integrity-gated backcasting.
 *
 * This mirrors ml/arrhenius_tti.py for the arithmetic, but the control flow
 * here is the part that matters and is specific to claims 11-13 of the filed
 * specification: correction is a privilege the reading has to earn, not a
 * default. Two independent signals must agree before a farmer's payment is
 * adjusted:
 *
 *   1. The QR code's declared harvest timestamp -> declared transit hours.
 *   2. The TTI strip's own accumulated thermal dose -> implied transit hours,
 *      computed against a fixed reference temperature.
 *
 * If they disagree by more than TTI_QR_MAX_DEVIATION_HOURS, someone has
 * either tampered with the QR data, tampered with or substituted the strip,
 * or the lot travelled through conditions the reference temperature does not
 * describe. In every one of those cases, guessing a corrected Brix is worse
 * than declining to correct at all — so the device declines, and hands the
 * lot to a human for manual quality assurance instead.
 */

#include "tti_decode.h"
#include "config.h"
#include <Arduino.h>
#include <cmath>

namespace {
bool sampleStripPatches(float& unreacted, float& reacted, float& active) {
  unreacted = 0.90f;
  reacted   = 0.20f;
  active    = 0.75f;
  return true;
}

float rateConstant(float tempC) {
  const float T = tempC + 273.15f;
  return expf(ARRHENIUS_LN_A - ARRHENIUS_EA / (R_GAS * T));
}
}  // namespace

namespace tti {

bool read(TtiReading& out) {
  out.valid = false;
  float unreacted, reacted, active;
  if (!sampleStripPatches(unreacted, reacted, active)) return false;

  const float span = unreacted - reacted;
  if (fabsf(span) < 0.05f) return false;

  float resp = (unreacted - active) / span;
  resp = fminf(fmaxf(resp, 0.0f), 1.0f);

  out.response  = resp;
  out.saturated = (resp >= TTI_RESPONSE_CEILING) || (resp <= TTI_RESPONSE_FLOOR);
  out.valid     = true;
  return true;
}

float doseFromResponse(float response) {
  float r = fminf(fmaxf(response, TTI_RESPONSE_FLOOR), TTI_RESPONSE_CEILING);
  return TTI_COUPLING * (-logf(1.0f - r));
}

BackcastResult backcast(float brixArrival, const TtiReading& t, float qrTransitHours) {
  BackcastResult r{};
  r.brixArrival = brixArrival;
  r.correctionApplied = false;

  if (!t.valid || t.saturated) {
    r.status = BackcastStatus::TTI_UNREADABLE;
    return r;
  }

  const float dose = doseFromResponse(t.response);

  // Implied hours: invert the dose assuming the reference temperature, purely
  // as a cross-check against the QR's declared hours. This is NOT the value
  // used for the actual correction below — it exists only to test agreement.
  const float kRef = rateConstant(TTI_ASSUMED_REF_TEMP_C);
  const float impliedHours = dose / kRef;

  if (fabsf(impliedHours - qrTransitHours) > TTI_QR_MAX_DEVIATION_HOURS) {
    r.status = BackcastStatus::INTEGRITY_MISMATCH;
    r.dose = dose;
    return r;
  }
  if (qrTransitHours > TTI_MAX_DECLARED_HOURS) {
    r.status = BackcastStatus::EXPOSURE_EXCEEDED;
    r.dose = dose;
    return r;
  }

  // Integrity check passed: apply the correction using the TTI's own dose
  // (the physically measured quantity), not the reference-temperature estimate
  // used above only for cross-validation.
  r.dose = dose;
  r.brixHarvest = brixArrival * expf(dose);

  const float z = 1.645f;
  const float dLo = fmaxf(0.0f, dose * (1.0f - z * DOSE_REL_SIGMA));
  const float dHi = dose * (1.0f + z * DOSE_REL_SIGMA);
  r.lo = brixArrival * expf(dLo);
  r.hi = brixArrival * expf(dHi);

  r.status = BackcastStatus::OK;
  r.correctionApplied = true;
  return r;
}

const char* backcastStatusText(BackcastStatus s) {
  switch (s) {
    case BackcastStatus::OK:                  return "Corrected";
    case BackcastStatus::INTEGRITY_MISMATCH:  return "QR/TTI mismatch - manual QA";
    case BackcastStatus::EXPOSURE_EXCEEDED:   return "Exposure too long - manual QA";
    case BackcastStatus::TTI_UNREADABLE:      return "TTI unreadable - manual QA";
    default:                                  return "Unknown";
  }
}

}  // namespace tti
