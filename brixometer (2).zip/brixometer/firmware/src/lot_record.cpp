/**
 * Lot custody records and grade signing.
 *
 * Every mill-mode scan produces a signed record, whether or not a correction
 * was applied. A record that says "TTI unreadable - manual QA, no correction
 * applied" is exactly as important to sign and store as one that says
 * "corrected, 17.4 -> 19.1 Bx" — both are part of the auditable chain of
 * custody the patent's claim 12 integrity check exists to support.
 */

#include "lot_record.h"
#include <ArduinoJson.h>
#include <FS.h>
#include <SD.h>
#include "config.h"

namespace {
bool g_sdReady = false;

String fixed(float v, int places = 3) {
  char buf[24];
  snprintf(buf, sizeof(buf), "%.*f", places, v);
  return String(buf);
}

// Placeholder — wire to mbedTLS Ed25519 with the key in encrypted NVS before
// any field unit ships. See docs/ROADMAP.md, Phase 2 exit criteria.
String ed25519Sign(const String& payload) {
  uint32_t h = 2166136261u;
  for (size_t i = 0; i < payload.length(); ++i) {
    h ^= (uint8_t)payload[i];
    h *= 16777619u;
  }
  char buf[24];
  snprintf(buf, sizeof(buf), "stub-%08x", h);
  return String(buf);
}
}  // namespace

namespace lot {

void begin() {
  g_sdReady = SD.begin(PIN_SD_CS);
  if (!g_sdReady) Serial.println("SD card unavailable - records held in NVS only");
}

String canonicalJson(const LotRecord& r) {
  const char* statusStr =
      r.status == BackcastStatus::OK ? "corrected" :
      r.status == BackcastStatus::INTEGRITY_MISMATCH ? "integrity_mismatch" :
      r.status == BackcastStatus::EXPOSURE_EXCEEDED ? "exposure_exceeded" :
      "tti_unreadable";

  String s = "{";
  s += "\"arrival_brix\":" + fixed(r.arrivalBrix) + ",";
  s += "\"declared_transit_hours\":" + fixed(r.declaredTransitHours, 2) + ",";
  s += "\"dose\":" + fixed(r.thermalDose, 6) + ",";
  s += "\"farmer_id\":\"" + r.farmerId + "\",";
  s += "\"fpo_id\":\"" + r.fpoId + "\",";
  if (r.status == BackcastStatus::OK) {
    s += "\"harvest_brix\":" + fixed(r.harvestBrix) + ",";
  }
  s += "\"harvest_epoch\":" + String(r.harvestEpoch) + ",";
  s += "\"lot_id\":\"" + r.lotId + "\",";
  s += "\"status\":\"" + String(statusStr) + "\",";
  s += "\"variety_hint\":\"" + r.varietyHint + "\"";
  s += "}";
  return s;
}

bool readQr(LotRecord& out) {
  const char* demo =
      "{\"lot_id\":\"LOT-2026-000431\",\"farmer_id\":\"F-8821\","
      "\"fpo_id\":\"FPO-TN-014\",\"variety_hint\":\"Co_86032\","
      "\"harvest_epoch\":1789200000,\"transit_hours\":14.5}";

  JsonDocument doc;
  if (deserializeJson(doc, demo)) return false;

  out.lotId               = doc["lot_id"].as<const char*>();
  out.farmerId            = doc["farmer_id"].as<const char*>();
  out.fpoId               = doc["fpo_id"].as<const char*>();
  out.varietyHint         = doc["variety_hint"].as<const char*>();
  out.harvestEpoch        = doc["harvest_epoch"].as<uint32_t>();
  out.declaredTransitHours = doc["transit_hours"].as<float>();
  return out.lotId.length() > 0;
}

bool signAndStore(LotRecord& rec) {
  rec.signature = ed25519Sign(canonicalJson(rec));
  if (!g_sdReady) return true;

  File f = SD.open("/grades.jsonl", FILE_APPEND);
  if (!f) return false;
  f.println(canonicalJson(rec) + ",\"sig\":\"" + rec.signature + "\"");
  f.close();
  return true;
}

bool appendFieldScan(const SpectralReading& r, const BrixPrediction& p, Badge b) {
  if (!g_sdReady) return false;
  File f = SD.open("/field_scans.jsonl", FILE_APPEND);
  if (!f) return false;
  String line = "{\"t\":" + String(r.timestampMs) +
                ",\"mu\":" + fixed(p.mu) +
                ",\"lo\":" + fixed(p.lo) +
                ",\"hi\":" + fixed(p.hi) +
                ",\"badge\":" + String((int)b) + ",\"refl\":[";
  for (int i = 0; i < N_SPECTRAL_CHANNELS; ++i) {
    line += fixed(r.reflectance[i], 5);
    if (i + 1 < N_SPECTRAL_CHANNELS) line += ",";
  }
  line += "]}";
  f.println(line);
  f.close();
  return true;
}

}  // namespace lot
