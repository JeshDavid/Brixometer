#pragma once
#include "nir_sensor.h"

enum class Badge : uint8_t { NONE, GREEN, YELLOW, RED };

struct BrixPrediction {
  float mu;       // point estimate, °Bx
  float sigma;    // model scale (not the guarantee)
  float lo, hi;   // conformal interval at the trained alpha
  float gate[8];  // expert routing weights, for diagnostics
  bool  valid;
};

namespace cmoe {
bool begin();
bool predict(const SpectralReading& r, BrixPrediction& out);
Badge badgeFor(float lo, float hi);
const char* badgeText(Badge b);
const char* badgeReason(Badge b, float lo, float hi);
}  // namespace cmoe
