#pragma once
#include <cstdint>

// Implements claims 4 and 5 of the filed specification: a reading is accepted
// only when contact force and device orientation are both within declared
// bounds. This exists because an NIR/RGB reading taken with inconsistent
// probe pressure or an implausible orientation is not a low-confidence
// reading — it is a measurement of the wrong thing, and no amount of downstream
// modelling (CMoE, conformal calibration) can recover from that. The gate runs
// before acquisition, not after, so a bad capture is never taken at all.

enum class ContactState : uint8_t { NOT_READY, FORCE_LOW, FORCE_HIGH, TILTED, READY };

namespace contact_gate {
bool begin();
ContactState poll();               // call each loop iteration; debounces internally
const char* stateText(ContactState s);
float lastForceN();
float lastTiltDeg();
}  // namespace contact_gate
