/**
 * CryoCivic / Brixometer — ESP32-S3 firmware entry point.
 *
 * One measurement head (104), one bayonet-mounted adapter swapped by the
 * user between the conical nose (110, field) and the flat-faced tip (111,
 * mill); a mode button (114) tells the firmware which is fitted. The
 * embedded control unit (116) runs two pipelines on the same captured data:
 *
 *   FIELD : NIR + cross-polar RGB -> CMoE -> Brix + conformal interval -> badge
 *   MILL  : NIR + cross-polar RGB -> arrival Brix; QR + TTI -> integrity-gated
 *           Arrhenius backcast -> signed grade (or a signed manual-QA flag)
 *
 * The design rule that governs this whole file: the device must be willing
 * to refuse, at every stage. A reading is not accepted without valid contact
 * force and orientation (claims 4-5). A saturated detector, a stale white
 * reference, or a too-wide prediction interval refuses rather than guesses.
 * A mill-side correction that fails its QR/TTI integrity check (claims 11-13)
 * is disabled outright, not approximated. A wrong confident number costs a
 * farmer a season, or costs a mill a disputed payment — either way it costs
 * more than a "not sure, try again."
 */

#include <Arduino.h>
#include <Wire.h>

#include "config.h"
#include "contact_gate.h"
#include "nir_sensor.h"
#include "cmoe_inference.h"
#include "tti_decode.h"
#include "lot_record.h"
#include "ui.h"

enum class Mode : uint8_t { FIELD, MILL };
static Mode g_mode = Mode::FIELD;
static uint32_t g_last_activity_ms = 0;

static void setLeds(Badge b) {
  digitalWrite(PIN_LED_GREEN,  b == Badge::GREEN);
  digitalWrite(PIN_LED_YELLOW, b == Badge::YELLOW);
  digitalWrite(PIN_LED_RED,    b == Badge::RED);
}

// Blocks (with a UI cue) until contact force + orientation are both in range,
// or the caller-supplied timeout elapses. Returns false on timeout so a scan
// attempt against nothing eventually gives up rather than hanging forever.
static bool waitForContact(uint32_t timeoutMs) {
  const uint32_t start = millis();
  while (millis() - start < timeoutMs) {
    ContactState s = contact_gate::poll();
    if (s == ContactState::READY) return true;
    ui::status(contact_gate::stateText(s));
    delay(30);
  }
  return false;
}

static void runFieldScan() {
  if (!waitForContact(5000)) { ui::error("No stable contact - try again"); return; }

  ui::status("Scanning...");
  SpectralReading r;
  if (!nir::acquire(r)) { ui::error(nir::lastErrorText()); setLeds(Badge::YELLOW); return; }

  BrixPrediction p;
  if (!cmoe::predict(r, p)) { ui::error("Model error"); setLeds(Badge::YELLOW); return; }

  if ((p.hi - p.lo) > MAX_ACCEPTABLE_INTERVAL_BX) {
    ui::error("Reading unclear - rescan");
    setLeds(Badge::YELLOW);
    return;
  }

  Badge badge = cmoe::badgeFor(p.lo, p.hi);
  setLeds(badge);
  ui::showFieldResult(p, badge);
  lot::appendFieldScan(r, p, badge);
}

static void runMillScan() {
  ui::status("Scan lot QR...");
  LotRecord lot;
  if (!lot::readQr(lot)) { ui::error("QR unreadable"); return; }

  ui::status("Scan TTI strip...");
  TtiReading tti;
  tti::read(tti);   // failure handled by the integrity gate below, not here

  if (!waitForContact(5000)) { ui::error("No stable contact - try again"); return; }

  ui::status("Scanning cut face...");
  SpectralReading r;
  if (!nir::acquire(r)) { ui::error(nir::lastErrorText()); return; }

  BrixPrediction arrival;
  if (!cmoe::predict(r, arrival)) { ui::error("Model error"); return; }

  BackcastResult bc = tti::backcast(arrival.mu, tti, lot.declaredTransitHours);

  lot.arrivalBrix = arrival.mu;
  lot.thermalDose = bc.dose;
  lot.status      = bc.status;
  lot.harvestBrix = (bc.status == BackcastStatus::OK) ? bc.brixHarvest : 0.0f;

  if (!lot::signAndStore(lot)) { ui::error("Signing failed"); return; }
  ui::showMillResult(lot, bc);
}

void setup() {
  Serial.begin(115200);
  delay(50);
  Serial.printf("\nCryoCivic / Brixometer %s booting\n", BRIX_FW_VERSION);

  pinMode(PIN_BTN_SCAN, INPUT_PULLUP);
  pinMode(PIN_BTN_MODE, INPUT_PULLUP);
  pinMode(PIN_LED_GREEN, OUTPUT);
  pinMode(PIN_LED_YELLOW, OUTPUT);
  pinMode(PIN_LED_RED, OUTPUT);
  pinMode(PIN_LAMP_EN, OUTPUT);

  Wire.begin(PIN_I2C_SDA, PIN_I2C_SCL, 400000);

  ui::begin();
  contact_gate::begin();
  if (!nir::begin())  { ui::fatal("NIR sensor not found"); }
  if (!cmoe::begin()) { ui::fatal("Model init failed"); }
  lot::begin();

  ui::status("Ready - FIELD");
  g_last_activity_ms = millis();
}

void loop() {
  if (digitalRead(PIN_BTN_MODE) == LOW) {
    delay(30);
    if (digitalRead(PIN_BTN_MODE) == LOW) {
      g_mode = (g_mode == Mode::FIELD) ? Mode::MILL : Mode::FIELD;
      ui::status(g_mode == Mode::FIELD ? "Ready - FIELD (fit conical tip)"
                                        : "Ready - MILL (fit flat tip)");
      setLeds(Badge::NONE);
      g_last_activity_ms = millis();
      while (digitalRead(PIN_BTN_MODE) == LOW) delay(10);
    }
  }

  if (digitalRead(PIN_BTN_SCAN) == LOW) {
    delay(30);
    if (digitalRead(PIN_BTN_SCAN) == LOW) {
      (g_mode == Mode::FIELD) ? runFieldScan() : runMillScan();
      g_last_activity_ms = millis();
      while (digitalRead(PIN_BTN_SCAN) == LOW) delay(10);
    }
  }

  if (millis() - g_last_activity_ms > IDLE_SLEEP_MS) {
    ui::status("Sleeping");
    digitalWrite(PIN_LAMP_EN, LOW);
    esp_sleep_enable_ext0_wakeup((gpio_num_t)PIN_BTN_SCAN, 0);
    esp_deep_sleep_start();
  }

  delay(10);
}
