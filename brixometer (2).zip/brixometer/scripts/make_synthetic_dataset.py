"""
Generate a physically-plausible synthetic calibration set so the pipeline is
runnable before real data exists.

This is scaffolding, not science. Every number the model produces on this data
is meaningless for agronomy — it exists so `train.py` and `evaluate.py` can be
smoke-tested, CI can run, and contributors can see shapes flow end to end.
Delete it from your results the moment real spectra arrive.

    python scripts/make_synthetic_dataset.py --n 600 --out ml/data/raw/synthetic.csv
"""

from __future__ import annotations

import argparse
from pathlib import Path

import numpy as np
import pandas as pd

VARIETIES = ["Co_86032", "Co_0238", "CoM_0265", "Co_0118"]
CHANNEL_NM = np.array([410, 435, 460, 485, 510, 535, 560, 585, 610,
                       645, 680, 705, 730, 760, 810, 860, 900, 940], float)


def synth(n: int, seed: int = 7) -> pd.DataFrame:
    rng = np.random.default_rng(seed)
    rows = []
    for i in range(n):
        var = VARIETIES[i % len(VARIETIES)]
        vi = VARIETIES.index(var)

        # Brix distribution differs slightly per variety, as in the field.
        brix = float(np.clip(rng.normal(17.5 + 0.6 * vi, 2.2), 10.0, 24.0))

        # Water/sugar absorption features near 900-940 nm scale with Brix;
        # rind pigment (chlorophyll ~680 nm) scales inversely with maturity.
        base = 0.55 + 0.05 * np.sin(CHANNEL_NM / 190.0)
        sugar_band = np.exp(-((CHANNEL_NM - 915.0) ** 2) / (2 * 45.0 ** 2))
        chl_band = np.exp(-((CHANNEL_NM - 680.0) ** 2) / (2 * 25.0 ** 2))

        R = (base
             - 0.020 * (brix - 17.0) * sugar_band
             + 0.030 * (21.0 - brix) / 10.0 * chl_band
             + 0.015 * vi * np.exp(-((CHANNEL_NM - 560.0) ** 2) / (2 * 60.0 ** 2)))

        R *= rng.normal(1.0, 0.03)                 # multiplicative scatter
        R += rng.normal(0.0, 0.004, CHANNEL_NM.size)  # detector noise
        R = np.clip(R, 0.02, 1.0)

        mg = float(np.clip(0.30 + 0.020 * (21.0 - brix) + rng.normal(0, 0.02), 0, 1))
        mr = float(np.clip(0.38 + 0.012 * (brix - 17.0) + rng.normal(0, 0.02), 0, 1))
        mb = float(np.clip(0.22 + rng.normal(0, 0.02), 0, 1))

        rows.append({
            **{f"ch_{j+1:02d}": R[j] for j in range(CHANNEL_NM.size)},
            "rgb_mean_r": mr, "rgb_mean_g": mg, "rgb_mean_b": mb,
            "rgb_std_g": float(abs(rng.normal(0.06, 0.015))),
            "rgb_gr_ratio": mg / mr,
            "rgb_edge": float(abs(rng.normal(0.05, 0.012))),
            "variety": var,
            "stem_id": f"S{i:04d}",
            "brix": brix,
        })
    return pd.DataFrame(rows)


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--n", type=int, default=600)
    ap.add_argument("--seed", type=int, default=7)
    ap.add_argument("--out", type=Path, default=Path("ml/data/raw/synthetic.csv"))
    a = ap.parse_args()
    a.out.parent.mkdir(parents=True, exist_ok=True)
    df = synth(a.n, a.seed)
    df.to_csv(a.out, index=False)
    print(f"Wrote {len(df)} synthetic rows -> {a.out}")
    print("REMINDER: synthetic data. Not a validation result.")


if __name__ == "__main__":
    main()
